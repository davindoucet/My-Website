"use client"

import { Card, CardContent } from "@/components/ui/card"
import { BookOpen, Award, Briefcase } from "lucide-react"
import { motion } from "framer-motion"
import { useLanguage } from "@/contexts/language-context"

export default function About() {
  const { t, language } = useLanguage()

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="about" className="py-20 bg-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-primary/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold text-gray-900">{t("about.title")}</h2>
          <div className="mt-2 h-1 w-20 bg-primary mx-auto"></div>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-3 gap-8 mb-16"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <motion.div variants={itemVariants}>
            <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden">
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{t("about.education")}</h3>
                <p className="text-gray-600">
                  {language === "en"
                    ? "Bachelor of Commerce in Finance with a minor in Forensic Psychology"
                    : "Baccalauréat en Commerce en Finance avec une mineure en Psychologie Judiciaire"}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden">
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{t("about.achievements")}</h3>
                <p className="text-gray-600">
                  {language === "en"
                    ? "Achieved significant portfolio growth with a peak ROI of 1740% using data-driven trading strategies"
                    : "Atteint une croissance significative du portefeuille avec un ROI maximal de 1740% en utilisant des stratégies de trading basées sur les données"}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden">
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Briefcase className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{t("about.experience")}</h3>
                <p className="text-gray-600">
                  {language === "en"
                    ? "Financial Analyst, Trader & Portfolio Manager"
                    : "Analyste Financier, Trader et Gestionnaire de Portefeuille"}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            className="relative flex justify-center"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="w-64 h-64 md:w-80 md:h-80 rounded-full border-4 border-primary/20 shadow-xl overflow-hidden relative z-10">
              <img
                src="/images/profile.png"
                alt="Davin Doucet"
                className="w-full h-full object-cover"
                style={{ objectPosition: "center 40%" }}
              />
            </div>
            <div className="absolute -bottom-4 -right-4 w-full h-full bg-primary/10 rounded-full z-0"></div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-2xl font-bold text-gray-900 mb-4">{t("about.whoIAm")}</h3>
            <p className="text-gray-700 mb-4 leading-relaxed">{t("about.bio1")}</p>
            <p className="text-gray-700 mb-6 leading-relaxed">{t("about.bio2")}</p>
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-1">{t("about.name")}</h4>
                <p className="text-gray-700">Davin Doucet</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-1">{t("about.email")}</h4>
                <p className="text-gray-700">davindoucet@hotmail.com</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-1">{t("about.location")}</h4>
                <p className="text-gray-700">Ottawa, ON, Canada</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-1">{t("about.languages")}</h4>
                <p className="text-gray-700">{language === "en" ? "English, French" : "Anglais, Français"}</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

