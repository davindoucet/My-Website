"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

type Testimonial = {
  id: number
  name: string
  title: {
    en: string
    fr: string
  }
  content: {
    en: string
    fr: string
  }
  image?: string
}

export default function Testimonials() {
  const { t, language } = useLanguage()
  const [activeIndex, setActiveIndex] = useState(0)

  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      title: {
        en: "Finance Professor, Carleton University",
        fr: "Professeure de Finance, Université Carleton",
      },
      content: {
        en: "Davin demonstrates exceptional analytical skills and a deep understanding of financial concepts. His ability to apply theoretical knowledge to practical scenarios sets him apart from his peers.",
        fr: "Davin démontre des compétences analytiques exceptionnelles et une compréhension approfondie des concepts financiers. Sa capacité à appliquer des connaissances théoriques à des scénarios pratiques le distingue de ses pairs.",
      },
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 2,
      name: "Michael Chen",
      title: {
        en: "Senior Financial Analyst, TD Bank",
        fr: "Analyste Financier Senior, Banque TD",
      },
      content: {
        en: "I had the pleasure of mentoring Davin during his internship. His attention to detail and commitment to excellence were impressive. He has a bright future in finance.",
        fr: "J'ai eu le plaisir de mentorer Davin pendant son stage. Son attention aux détails et son engagement envers l'excellence étaient impressionnants. Il a un avenir brillant dans la finance.",
      },
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 3,
      name: "Emma Rodriguez",
      title: {
        en: "Team Lead, Sprott Finance Students' Association",
        fr: "Chef d'Équipe, Association des Étudiants en Finance de Sprott",
      },
      content: {
        en: "Working with Davin on association projects has been a fantastic experience. His innovative approaches to financial modeling and ability to communicate complex ideas clearly make him an invaluable team member.",
        fr: "Travailler avec Davin sur des projets d'association a été une expérience fantastique. Ses approches innovantes de la modélisation financière et sa capacité à communiquer clairement des idées complexes font de lui un membre d'équipe inestimable.",
      },
      image: "/placeholder.svg?height=100&width=100",
    },
  ]

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section className="py-20 bg-white dark:bg-gray-900 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-primary/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white">
            {language === "en" ? "Testimonials" : "Témoignages"}
          </h2>
          <div className="mt-2 h-1 w-20 bg-primary mx-auto"></div>
          <p className="mt-4 text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">
            {language === "en"
              ? "What others say about my work and expertise"
              : "Ce que les autres disent de mon travail et de mon expertise"}
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeIndex}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-none shadow-xl dark:bg-gray-800">
                <CardContent className="p-8 md:p-12">
                  <Quote className="h-12 w-12 text-primary/20 mb-6" />

                  <p className="text-xl md:text-2xl text-gray-700 dark:text-gray-300 mb-8 italic">
                    "{testimonials[activeIndex].content[language]}"
                  </p>

                  <div className="flex items-center">
                    {testimonials[activeIndex].image && (
                      <div className="mr-4 w-16 h-16 rounded-full overflow-hidden">
                        <img
                          src={testimonials[activeIndex].image || "/placeholder.svg"}
                          alt={testimonials[activeIndex].name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 dark:text-white">
                        {testimonials[activeIndex].name}
                      </h4>
                      <p className="text-gray-600 dark:text-gray-400">{testimonials[activeIndex].title[language]}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-center mt-8 space-x-4">
            <button
              onClick={prevTestimonial}
              className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 hover:bg-primary/20 transition-colors"
              aria-label={language === "en" ? "Previous testimonial" : "Témoignage précédent"}
            >
              <ChevronLeft className="h-6 w-6 text-gray-700 dark:text-gray-300" />
            </button>

            <div className="flex items-center space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === activeIndex ? "bg-primary" : "bg-gray-300 dark:bg-gray-600 hover:bg-primary/50"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            <button
              onClick={nextTestimonial}
              className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 hover:bg-primary/20 transition-colors"
              aria-label={language === "en" ? "Next testimonial" : "Témoignage suivant"}
            >
              <ChevronRight className="h-6 w-6 text-gray-700 dark:text-gray-300" />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

