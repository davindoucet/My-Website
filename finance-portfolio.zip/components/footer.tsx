"use client"

import { useState } from "react"
import { Github, Linkedin, Mail, FileText } from "lucide-react"
import { motion } from "framer-motion"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useLanguage } from "@/contexts/language-context"
import { useRouter } from "next/navigation"

export default function Footer() {
  const [policyOpen, setPolicyOpen] = useState(false)
  const [policyType, setPolicyType] = useState<"privacy" | "terms" | "cookies" | null>(null)
  const { t, language } = useLanguage()
  const router = useRouter()

  const openPolicy = (type: "privacy" | "terms" | "cookies") => {
    setPolicyType(type)
    setPolicyOpen(true)
  }

  // Update the viewResume function with the new preview link
  const viewResume = () => {
    if (language === "en" && window.confirm("Would you like to download the resume instead of viewing it?")) {
      window.open("https://drive.google.com/uc?export=download&id=1UcJuRFPgTNQQG0VUR1HR06VlvOJWFniv", "_blank")
    } else {
      router.push("/resume")
    }
  }

  return (
    <footer className="bg-gray-900 text-white py-12 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl opacity-20"></div>
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-primary/10 rounded-full blur-3xl opacity-20"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <motion.div
            className="mb-6 md:mb-0"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-2xl font-bold">
              Davin<span className="text-primary">Doucet</span>
            </h3>
            <p className="mt-2 text-gray-400 max-w-md">
              {language === "en"
                ? "A dedicated finance student with expertise in financial analysis, trading & investing, and portfolio management."
                : "Un étudiant en finance dévoué avec une expertise en analyse financière, trading et investissement, et gestion de portefeuille."}
            </p>
          </motion.div>

          <motion.div
            className="flex space-x-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <a
              href="https://github.com/davindoucet"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gray-800 p-3 rounded-full hover:bg-primary hover:text-white transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
            >
              <Github className="h-5 w-5" />
              <span className="sr-only">GitHub</span>
            </a>
            <a
              href="https://www.linkedin.com/in/davin-doucet"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gray-800 p-3 rounded-full hover:bg-primary hover:text-white transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
            >
              <Linkedin className="h-5 w-5" />
              <span className="sr-only">LinkedIn</span>
            </a>
            <button
              onClick={viewResume}
              className="bg-gray-800 p-3 rounded-full hover:bg-primary hover:text-white transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
            >
              <FileText className="h-5 w-5" />
              <span className="sr-only">{t("resume.viewResume")}</span>
            </button>
            <a
              href="mailto:davindoucet@hotmail.com"
              className="bg-gray-800 p-3 rounded-full hover:bg-primary hover:text-white transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
            >
              <Mail className="h-5 w-5" />
              <span className="sr-only">Email</span>
            </a>
          </motion.div>
        </div>

        <motion.div
          className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} Davin Doucet. {t("footer.rights")}
          </p>
          <div className="mt-4 md:mt-0">
            <ul className="flex space-x-6 text-sm text-gray-400">
              <li>
                <button
                  onClick={() => openPolicy("privacy")}
                  className="hover:text-primary transition-colors duration-300"
                >
                  {t("footer.privacy")}
                </button>
              </li>
              <li>
                <button
                  onClick={() => openPolicy("terms")}
                  className="hover:text-primary transition-colors duration-300"
                >
                  {t("footer.terms")}
                </button>
              </li>
              <li>
                <button
                  onClick={() => openPolicy("cookies")}
                  className="hover:text-primary transition-colors duration-300"
                >
                  {t("footer.cookies")}
                </button>
              </li>
            </ul>
          </div>
        </motion.div>
      </div>

      {/* Policy Dialogs */}
      <Dialog open={policyOpen} onOpenChange={setPolicyOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto dark:bg-gray-800 dark:text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">
              {policyType === "privacy" && t("footer.privacy")}
              {policyType === "terms" && t("footer.terms")}
              {policyType === "cookies" && t("footer.cookies")}
            </DialogTitle>
          </DialogHeader>

          {policyType === "privacy" && <PrivacyPolicy />}
          {policyType === "terms" && <TermsOfService />}
          {policyType === "cookies" && <CookiesPolicy />}
        </DialogContent>
      </Dialog>
    </footer>
  )
}

function PrivacyPolicy() {
  const { language } = useLanguage()

  if (language === "en") {
    return (
      <div className="text-gray-700 dark:text-gray-300 space-y-4 text-sm">
        <p className="text-gray-500 dark:text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">1. Introduction</h3>
        <p>
          Welcome to Davin Doucet's personal portfolio website. I respect your privacy and am committed to protecting
          your personal data. This Privacy Policy explains how I collect, use, and safeguard your information when you
          visit my website.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">2. Information I Collect</h3>
        <p>
          <strong>Personal Information:</strong> When you use the contact form, I collect your name, email address, and
          any other information you provide in your message.
        </p>
        <p>
          <strong>Usage Data:</strong> I may collect information on how you interact with my website, including pages
          visited, time spent on pages, and other analytical data.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">3. How I Use Your Information</h3>
        <ul className="list-disc pl-5 space-y-2">
          <li>To respond to your inquiries and messages</li>
          <li>To improve my website and user experience</li>
          <li>To analyze usage patterns and optimize content</li>
          <li>To protect my website against unauthorized access</li>
        </ul>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">4. Data Security</h3>
        <p>
          I implement appropriate security measures to protect your personal information. However, no method of
          transmission over the Internet or electronic storage is 100% secure, and I cannot guarantee absolute security.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">5. Third-Party Services</h3>
        <p>
          My website may use third-party services such as analytics providers and email processing services. These third
          parties may have access to your personal information only to perform specific tasks on my behalf and are
          obligated not to disclose or use it for any other purpose.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">6. Your Rights</h3>
        <p>Depending on your location, you may have rights regarding your personal data, including:</p>
        <ul className="list-disc pl-5 space-y-2">
          <li>The right to access your personal data</li>
          <li>The right to rectify inaccurate data</li>
          <li>The right to request deletion of your data</li>
          <li>The right to restrict or object to processing</li>
          <li>The right to data portability</li>
        </ul>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">7. Changes to This Privacy Policy</h3>
        <p>
          I may update this Privacy Policy from time to time. I will notify you of any changes by posting the new
          Privacy Policy on this page and updating the "Last updated" date.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">8. Contact Information</h3>
        <p>If you have any questions about this Privacy Policy, please contact me at davindoucet@hotmail.com.</p>
      </div>
    )
  } else {
    return (
      <div className="text-gray-700 dark:text-gray-300 space-y-4 text-sm">
        <p className="text-gray-500 dark:text-gray-400">Dernière mise à jour: {new Date().toLocaleDateString()}</p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">1. Introduction</h3>
        <p>
          Bienvenue sur le site portfolio personnel de Davin Doucet. Je respecte votre vie privée et m'engage à protéger
          vos données personnelles. Cette politique de confidentialité explique comment je collecte, utilise et protège
          vos informations lorsque vous visitez mon site web.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">2. Informations que je collecte</h3>
        <p>
          <strong>Informations personnelles:</strong> Lorsque vous utilisez le formulaire de contact, je collecte votre
          nom, adresse e-mail et toute autre information que vous fournissez dans votre message.
        </p>
        <p>
          <strong>Données d'utilisation:</strong> Je peux collecter des informations sur la façon dont vous interagissez
          avec mon site web, y compris les pages visitées, le temps passé sur les pages et d'autres données analytiques.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">3. Comment j'utilise vos informations</h3>
        <ul className="list-disc pl-5 space-y-2">
          <li>Pour répondre à vos demandes et messages</li>
          <li>Pour améliorer mon site web et l'expérience utilisateur</li>
          <li>Pour analyser les modèles d'utilisation et optimiser le contenu</li>
          <li>Pour protéger mon site web contre les accès non autorisés</li>
        </ul>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">4. Sécurité des données</h3>
        <p>
          Je mets en œuvre des mesures de sécurité appropriées pour protéger vos informations personnelles. Cependant,
          aucune méthode de transmission sur Internet ou de stockage électronique n'est sécurisée à 100%, et je ne peux
          garantir une sécurité absolue.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">5. Services tiers</h3>
        <p>
          Mon site web peut utiliser des services tiers tels que des fournisseurs d'analyses et des services de
          traitement d'e-mails. Ces tiers peuvent avoir accès à vos informations personnelles uniquement pour effectuer
          des tâches spécifiques en mon nom et sont obligés de ne pas les divulguer ou les utiliser à d'autres fins.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">6. Vos droits</h3>
        <p>Selon votre emplacement, vous pouvez avoir des droits concernant vos données personnelles, notamment:</p>
        <ul className="list-disc pl-5 space-y-2">
          <li>Le droit d'accéder à vos données personnelles</li>
          <li>Le droit de rectifier des données inexactes</li>
          <li>Le droit de demander la suppression de vos données</li>
          <li>Le droit de restreindre ou de s'opposer au traitement</li>
          <li>Le droit à la portabilité des données</li>
        </ul>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">
          7. Modifications de cette politique de confidentialité
        </h3>
        <p>
          Je peux mettre à jour cette politique de confidentialité de temps à autre. Je vous informerai de tout
          changement en publiant la nouvelle politique de confidentialité sur cette page et en mettant à jour la date de
          "Dernière mise à jour".
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">8. Coordonnées</h3>
        <p>
          Si vous avez des questions concernant cette politique de confidentialité, veuillez me contacter à
          davindoucet@hotmail.com.
        </p>
      </div>
    )
  }
}

function TermsOfService() {
  const { language } = useLanguage()

  if (language === "en") {
    return (
      <div className="text-gray-700 dark:text-gray-300 space-y-4 text-sm">
        <p className="text-gray-500 dark:text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">1. Introduction</h3>
        <p>
          Welcome to Davin Doucet's portfolio website. By accessing or using this website, you agree to be bound by
          these Terms of Service. If you disagree with any part of these terms, please do not use my website.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">2. Intellectual Property</h3>
        <p>
          The content on this website, including text, graphics, logos, images, and software, is the property of Davin
          Doucet and is protected by copyright and other intellectual property laws. You may not use, reproduce,
          distribute, or create derivative works from this content without explicit permission.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">3. User Conduct</h3>
        <p>When using this website, you agree not to:</p>
        <ul className="list-disc pl-5 space-y-2">
          <li>Use the website in any way that violates applicable laws or regulations</li>
          <li>Attempt to gain unauthorized access to any portion of the website</li>
          <li>Use the website to transmit malware, viruses, or other malicious code</li>
          <li>Interfere with or disrupt the integrity or performance of the website</li>
          <li>Collect or track personal information of other users</li>
        </ul>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">4. Disclaimer of Warranties</h3>
        <p>
          This website is provided "as is" and "as available" without any warranties, expressed or implied. I do not
          guarantee that the website will be error-free, secure, or uninterrupted.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">5. Limitation of Liability</h3>
        <p>
          In no event shall Davin Doucet be liable for any indirect, incidental, special, consequential, or punitive
          damages arising out of or related to your use of the website.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">6. External Links</h3>
        <p>
          This website may contain links to external websites that are not operated by me. I have no control over the
          content and practices of these sites and cannot accept responsibility for their respective privacy policies.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">7. Modifications</h3>
        <p>
          I reserve the right to modify or replace these Terms of Service at any time. It is your responsibility to
          check these terms periodically for changes.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">8. Governing Law</h3>
        <p>
          These Terms of Service shall be governed by and construed in accordance with the laws of Canada, without
          regard to its conflict of law provisions.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">9. Contact Information</h3>
        <p>If you have any questions about these Terms of Service, please contact me at davindoucet@hotmail.com.</p>
      </div>
    )
  } else {
    return (
      <div className="text-gray-700 dark:text-gray-300 space-y-4 text-sm">
        <p className="text-gray-500 dark:text-gray-400">Dernière mise à jour: {new Date().toLocaleDateString()}</p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">1. Introduction</h3>
        <p>
          Bienvenue sur le site portfolio de Davin Doucet. En accédant ou en utilisant ce site web, vous acceptez d'être
          lié par ces Conditions d'utilisation. Si vous n'êtes pas d'accord avec une partie de ces conditions, veuillez
          ne pas utiliser mon site web.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">2. Propriété intellectuelle</h3>
        <p>
          Le contenu de ce site web, y compris le texte, les graphiques, les logos, les images et les logiciels, est la
          propriété de Davin Doucet et est protégé par le droit d'auteur et d'autres lois sur la propriété
          intellectuelle. Vous ne pouvez pas utiliser, reproduire, distribuer ou créer des œuvres dérivées de ce contenu
          sans autorisation explicite.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">3. Conduite de l'utilisateur</h3>
        <p>En utilisant ce site web, vous acceptez de ne pas:</p>
        <ul className="list-disc pl-5 space-y-2">
          <li>Utiliser le site web d'une manière qui viole les lois ou réglementations applicables</li>
          <li>Tenter d'accéder sans autorisation à une partie du site web</li>
          <li>
            Utiliser le site web pour transmettre des logiciels malveillants, des virus ou d'autres codes malveillants
          </li>
          <li>Interférer avec ou perturber l'intégrité ou la performance du site web</li>
          <li>Collecter ou suivre les informations personnelles d'autres utilisateurs</li>
        </ul>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">4. Avis de non-responsabilité</h3>
        <p>
          Ce site web est fourni "tel quel" et "tel que disponible" sans aucune garantie, expresse ou implicite. Je ne
          garantis pas que le site web sera sans erreur, sécurisé ou ininterrompu.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">5. Limitation de responsabilité</h3>
        <p>
          En aucun cas, Davin Doucet ne sera responsable des dommages indirects, accessoires, spéciaux, consécutifs ou
          punitifs découlant de ou liés à votre utilisation du site web.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">6. Liens externes</h3>
        <p>
          Ce site web peut contenir des liens vers des sites web externes qui ne sont pas exploités par moi. Je n'ai
          aucun contrôle sur le contenu et les pratiques de ces sites et ne peux accepter la responsabilité de leurs
          politiques de confidentialité respectives.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">7. Modifications</h3>
        <p>
          Je me réserve le droit de modifier ou de remplacer ces Conditions d'utilisation à tout moment. Il est de votre
          responsabilité de vérifier ces conditions périodiquement pour les changements.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">8. Loi applicable</h3>
        <p>
          Ces Conditions d'utilisation seront régies et interprétées conformément aux lois du Canada, sans égard à ses
          dispositions relatives aux conflits de lois.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">9. Coordonnées</h3>
        <p>
          Si vous avez des questions concernant ces Conditions d'utilisation, veuillez me contacter à
          davindoucet@hotmail.com.
        </p>
      </div>
    )
  }
}

function CookiesPolicy() {
  const { language } = useLanguage()

  if (language === "en") {
    return (
      <div className="text-gray-700 dark:text-gray-300 space-y-4 text-sm">
        <p className="text-gray-500 dark:text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">1. Introduction</h3>
        <p>
          This Cookies Policy explains how Davin Doucet's portfolio website uses cookies and similar technologies to
          recognize you when you visit my website. It explains what these technologies are and why I use them, as well
          as your rights to control my use of them.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">2. What Are Cookies?</h3>
        <p>
          Cookies are small data files that are placed on your computer or mobile device when you visit a website.
          Cookies are widely used by website owners to make their websites work, or to work more efficiently, as well as
          to provide reporting information.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">3. Types of Cookies I Use</h3>
        <p>
          <strong>Essential Cookies:</strong> These cookies are necessary for the website to function properly and
          cannot be switched off in my systems. They are usually only set in response to actions made by you which
          amount to a request for services, such as setting your privacy preferences, logging in, or filling in forms.
        </p>
        <p>
          <strong>Analytics Cookies:</strong> These cookies allow me to count visits and traffic sources so I can
          measure and improve the performance of my site. They help me to know which pages are the most and least
          popular and see how visitors move around the site.
        </p>
        <p>
          <strong>Functionality Cookies:</strong> These cookies enable the website to provide enhanced functionality and
          personalization. They may be set by me or by third-party providers whose services I have added to my pages.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">4. Third-Party Cookies</h3>
        <p>
          In addition to my own cookies, I may also use various third-party cookies to report usage statistics of the
          website and deliver advertisements on and through the website.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">5. How to Control Cookies</h3>
        <p>
          Most web browsers allow you to control cookies through their settings preferences. However, if you limit the
          ability of websites to set cookies, you may worsen your overall user experience, since it will no longer be
          personalized to you.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">6. Updates to This Cookies Policy</h3>
        <p>
          I may update this Cookies Policy from time to time in order to reflect changes to the cookies I use or for
          other operational, legal, or regulatory reasons. Please therefore re-visit this Cookies Policy regularly to
          stay informed about my use of cookies and related technologies.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">7. Contact Information</h3>
        <p>
          If you have any questions about my use of cookies or other technologies, please contact me at
          davindoucet@hotmail.com.
        </p>
      </div>
    )
  } else {
    return (
      <div className="text-gray-700 dark:text-gray-300 space-y-4 text-sm">
        <p className="text-gray-500 dark:text-gray-400">Dernière mise à jour: {new Date().toLocaleDateString()}</p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">1. Introduction</h3>
        <p>
          Cette Politique de Cookies explique comment le site portfolio de Davin Doucet utilise les cookies et
          technologies similaires pour vous reconnaître lorsque vous visitez mon site web. Elle explique ce que sont ces
          technologies et pourquoi je les utilise, ainsi que vos droits pour contrôler mon utilisation de celles-ci.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">2. Que sont les cookies?</h3>
        <p>
          Les cookies sont de petits fichiers de données qui sont placés sur votre ordinateur ou appareil mobile lorsque
          vous visitez un site web. Les cookies sont largement utilisés par les propriétaires de sites web pour faire
          fonctionner leurs sites web, ou pour les faire fonctionner plus efficacement, ainsi que pour fournir des
          informations de rapport.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">3. Types de cookies que j'utilise</h3>
        <p>
          <strong>Cookies essentiels:</strong> Ces cookies sont nécessaires au bon fonctionnement du site web et ne
          peuvent pas être désactivés dans mes systèmes. Ils sont généralement définis uniquement en réponse à des
          actions que vous effectuez qui équivalent à une demande de services, comme la définition de vos préférences de
          confidentialité, la connexion ou le remplissage de formulaires.
        </p>
        <p>
          <strong>Cookies d'analyse:</strong> Ces cookies me permettent de compter les visites et les sources de trafic
          afin que je puisse mesurer et améliorer les performances de mon site. Ils m'aident à savoir quelles pages sont
          les plus et les moins populaires et à voir comment les visiteurs se déplacent sur le site.
        </p>
        <p>
          <strong>Cookies de fonctionnalité:</strong> Ces cookies permettent au site web de fournir une fonctionnalité
          et une personnalisation améliorées. Ils peuvent être définis par moi ou par des fournisseurs tiers dont j'ai
          ajouté les services à mes pages.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">4. Cookies tiers</h3>
        <p>
          En plus de mes propres cookies, je peux également utiliser divers cookies tiers pour rapporter les
          statistiques d'utilisation du site web et diffuser des publicités sur et à travers le site web.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">5. Comment contrôler les cookies</h3>
        <p>
          La plupart des navigateurs web vous permettent de contrôler les cookies via leurs préférences de paramètres.
          Cependant, si vous limitez la capacité des sites web à définir des cookies, vous pourriez dégrader votre
          expérience utilisateur globale, car elle ne sera plus personnalisée pour vous.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">6. Mises à jour de cette politique de cookies</h3>
        <p>
          Je peux mettre à jour cette politique de cookies de temps à autre afin de refléter les changements dans les
          cookies que j'utilise ou pour d'autres raisons opérationnelles, légales ou réglementaires. Veuillez donc
          revisiter régulièrement cette politique de cookies pour rester informé de mon utilisation des cookies et des
          technologies connexes.
        </p>

        <h3 className="text-lg font-semibold mt-4 dark:text-white">7. Coordonnées</h3>
        <p>
          Si vous avez des questions sur mon utilisation des cookies ou d'autres technologies, veuillez me contacter à
          davindoucet@hotmail.com.
        </p>
      </div>
    )
  }
}

