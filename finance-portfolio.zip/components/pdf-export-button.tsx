"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { FileDown, Loader2 } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"
import { jsPDF } from "jspdf"
import "jspdf-autotable"

type PDFExportButtonProps = {
  title: string
  data: Record<string, any>
  filename?: string
  onExport?: () => void
}

export default function PDFExportButton({ title, data, filename = "export.pdf", onExport }: PDFExportButtonProps) {
  const { language } = useLanguage()
  const [isExporting, setIsExporting] = useState(false)

  const exportToPDF = async () => {
    setIsExporting(true)

    try {
      // Create a new PDF document
      const doc = new jsPDF()

      // Add title
      doc.setFontSize(20)
      doc.text(title, 20, 20)

      // Add date
      doc.setFontSize(10)
      doc.text(`${language === "en" ? "Generated on" : "Généré le"}: ${new Date().toLocaleDateString()}`, 20, 30)

      // Add data as table
      const tableData = Object.entries(data).map(([key, value]) => {
        // Format the value based on its type
        let formattedValue = value
        if (typeof value === "number") {
          formattedValue = value.toLocaleString(undefined, {
            maximumFractionDigits: 2,
          })
          // Add dollar sign for monetary values
          if (
            key.toLowerCase().includes("amount") ||
            key.toLowerCase().includes("payment") ||
            key.toLowerCase().includes("value") ||
            key.toLowerCase().includes("income")
          ) {
            formattedValue = `$${formattedValue}`
          }
          // Add percentage sign for rates
          if (key.toLowerCase().includes("rate") || key.toLowerCase().includes("percent")) {
            formattedValue = `${formattedValue}%`
          }
        }

        return [key, formattedValue]
      })

      // @ts-ignore - jspdf-autotable extends jsPDF prototype
      doc.autoTable({
        startY: 40,
        head: [[language === "en" ? "Parameter" : "Paramètre", language === "en" ? "Value" : "Valeur"]],
        body: tableData,
        theme: "striped",
        headStyles: { fillColor: [156, 102, 68] },
        margin: { top: 40 },
      })

      // Add footer
      const pageCount = doc.internal.getNumberOfPages()
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i)
        doc.setFontSize(8)
        doc.text(
          "Davin Doucet Finance Portfolio",
          doc.internal.pageSize.getWidth() / 2,
          doc.internal.pageSize.getHeight() - 10,
          { align: "center" },
        )
      }

      // Save the PDF
      doc.save(filename)

      // Call onExport callback if provided
      if (onExport) onExport()
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <Button
      onClick={exportToPDF}
      variant="outline"
      className="border-primary text-primary hover:bg-primary/10"
      disabled={isExporting}
    >
      {isExporting ? (
        <>
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          {language === "en" ? "Exporting..." : "Exportation..."}
        </>
      ) : (
        <>
          <FileDown className="h-4 w-4 mr-2" />
          {language === "en" ? "Export PDF" : "Exporter PDF"}
        </>
      )}
    </Button>
  )
}

