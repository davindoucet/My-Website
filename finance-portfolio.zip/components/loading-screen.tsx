"use client"

import { motion } from "framer-motion"
import { useTheme } from "@/contexts/theme-context"

export default function LoadingScreen() {
  const { theme } = useTheme()

  return (
    <div className="fixed inset-0 bg-white dark:bg-gray-900 flex items-center justify-center z-50">
      <div className="text-center">
        <motion.div
          className="flex items-center justify-center mb-8"
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-4xl font-bold text-gray-900 dark:text-white">
            Davin<span className="text-primary">Doucet</span>
          </div>
        </motion.div>

        <motion.div
          className="w-64 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden mx-auto"
          initial={{ width: 0 }}
          animate={{ width: "16rem" }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <motion.div
            className="h-full bg-primary"
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 1.5, delay: 0.3, ease: "easeInOut" }}
          />
        </motion.div>

        <motion.p
          className="mt-4 text-gray-600 dark:text-gray-400"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          Loading portfolio...
        </motion.p>
      </div>
    </div>
  )
}

