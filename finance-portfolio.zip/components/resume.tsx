"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Briefcase, GraduationCap } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

export default function Resume() {
  const { t, language } = useLanguage()

  return (
    <section id="resume" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">{t("resume.title")}</h2>
          <div className="mt-2 h-1 w-20 bg-primary mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Education */}
          <div>
            <div className="flex items-center mb-8">
              <div className="bg-primary/10 p-3 rounded-full mr-4">
                <GraduationCap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">{t("resume.education")}</h3>
            </div>

            <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-1/2 before:h-full before:w-0.5 before:bg-gray-200">
              {[
                {
                  period: language === "en" ? "2022 - 2026 (Expected)" : "2022 - 2026 (Prévu)",
                  title:
                    language === "en"
                      ? "Bachelor of Commerce (Honors) in Finance with a minor in Forensic Psychology"
                      : "Baccalauréat en Commerce (Avec Distinction) en Finance avec une mineure en Psychologie Judiciaire",
                  institution: language === "en" ? "Carleton University" : "Université Carleton",
                  description:
                    language === "en"
                      ? "Relevant Coursework: Derivatives, Investment, Financial Accounting, Business Finance"
                      : "Cours Pertinents: Dérivés, Investissement, Comptabilité Financière, Finance d'Entreprise",
                },
                {
                  period: "2020 - 2022",
                  title: language === "en" ? "Engineering Technologies" : "Technologies d'Ingénierie",
                  institution: language === "en" ? "John Abbott College" : "Collège John Abbott",
                  description:
                    language === "en"
                      ? "Relevant Coursework: Mathematical Models 1, Electric Assembly, Control Logic, Design and Simulation"
                      : "Cours Pertinents: Modèles Mathématiques 1, Assemblage Électrique, Logique de Contrôle, Conception et Simulation",
                },
              ].map((item, index) => (
                <Card key={index} className="relative border-none shadow-md ml-8">
                  <div className="absolute -left-12 top-5 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <div className="w-3 h-3 bg-white rounded-full"></div>
                  </div>
                  <CardContent className="p-6">
                    <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-sm rounded-full mb-2">
                      {item.period}
                    </span>
                    <h4 className="text-xl font-semibold text-gray-900 mb-1">{item.title}</h4>
                    <p className="text-gray-600 mb-2">{item.institution}</p>
                    <p className="text-gray-700">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Experience */}
          <div>
            <div className="flex items-center mb-8">
              <div className="bg-primary/10 p-3 rounded-full mr-4">
                <Briefcase className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">{t("resume.experience")}</h3>
            </div>

            <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-1/2 before:h-full before:w-0.5 before:bg-gray-200">
              {[
                {
                  period: language === "en" ? "May 2024 - Present" : "Mai 2024 - Présent",
                  title: language === "en" ? "Financial Analyst" : "Analyste Financier",
                  company: "Duct Masters Inc.",
                  description:
                    language === "en"
                      ? "Analyzed financial statements for budgets exceeding $100,000, supporting forecasting and cash flow management, enhancing financial accuracy by 12%."
                      : "Analyse des états financiers pour des budgets dépassant 100 000 $, soutien aux prévisions et à la gestion des flux de trésorerie, amélioration de la précision financière de 12%.",
                },
                {
                  period: language === "en" ? "Jan 2024 - Present" : "Jan 2024 - Présent",
                  title: language === "en" ? "Trader & Portfolio Manager" : "Trader et Gestionnaire de Portefeuille",
                  company:
                    language === "en" ? "Independent Trading & Investments" : "Trading et Investissements Indépendants",
                  description:
                    language === "en"
                      ? "Achieved significant portfolio growth, including a peak ROI of 1740%, by employing high-frequency trading and data-driven strategies. Execute day and swing trades while applying hedging and risk management techniques."
                      : "Réalisation d'une croissance significative du portefeuille, incluant un ROI maximal de 1740%, en utilisant des stratégies de trading à haute fréquence et basées sur les données. Exécution de trades journaliers et de position tout en appliquant des techniques de couverture et de gestion des risques.",
                },
                {
                  period: language === "en" ? "Nov 2023 - May 2024" : "Nov 2023 - Mai 2024",
                  title: language === "en" ? "Security Supervisor" : "Superviseur de Sécurité",
                  company: "Commissionaire",
                  description:
                    language === "en"
                      ? "Ensured the security and confidentiality of high-risk facilities and information, maintaining compliance with strict protocols. Trained junior security staff, enhancing response efficiency by 15%."
                      : "Assurance de la sécurité et de la confidentialité des installations et informations à haut risque, maintien de la conformité avec des protocoles stricts. Formation du personnel de sécurité junior, amélioration de l'efficacité de réponse de 15%.",
                },
                {
                  period: language === "en" ? "Sep 2021 - June 2022" : "Sep 2021 - Juin 2022",
                  title: language === "en" ? "Team Member" : "Membre d'Équipe",
                  company:
                    language === "en"
                      ? "John Abbott College Lacrosse Team"
                      : "Équipe de Lacrosse du Collège John Abbott",
                  description:
                    language === "en"
                      ? "Participated in 12+ collegiate matches, developing strong teamwork, leadership, and discipline."
                      : "Participation à plus de 12 matchs collégiaux, développement d'un fort esprit d'équipe, de leadership et de discipline.",
                },
              ].map((item, index) => (
                <Card key={index} className="relative border-none shadow-md ml-8">
                  <div className="absolute -left-12 top-5 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <div className="w-3 h-3 bg-white rounded-full"></div>
                  </div>
                  <CardContent className="p-6">
                    <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-sm rounded-full mb-2">
                      {item.period}
                    </span>
                    <h4 className="text-xl font-semibold text-gray-900 mb-1">{item.title}</h4>
                    <p className="text-gray-600 mb-2">{item.company}</p>
                    <p className="text-gray-700">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

