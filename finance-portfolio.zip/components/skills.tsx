"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import {
  LineChart,
  BarChart,
  PieChart,
  Calculator,
  Database,
  Code,
  PenTool,
  Briefcase,
  Globe,
  BookOpen,
  Shield,
  TrendingUp,
  DollarSign,
  FileText,
  BarChartIcon as ChartBar,
  Landmark,
} from "lucide-react"
import { motion } from "framer-motion"
import { useLanguage } from "@/contexts/language-context"

export default function Skills() {
  const [activeTab, setActiveTab] = useState("technical")
  const { t, language } = useLanguage()

  const technicalSkills = [
    {
      name: language === "en" ? "Financial Analysis" : "Analyse Financière",
      icon: LineChart,
      description:
        language === "en"
          ? "Budget analysis, forecasting, and financial modeling"
          : "Analyse budgétaire, prévisions et modélisation financière",
    },
    {
      name: language === "en" ? "Python Programming" : "Programmation Python",
      icon: Code,
      description:
        language === "en"
          ? "Automation, data analysis, and financial modeling"
          : "Automatisation, analyse de données et modélisation financière",
    },
    {
      name: language === "en" ? "Investment Management" : "Gestion d'Investissement",
      icon: BarChart,
      description:
        language === "en"
          ? "Portfolio optimization and risk management"
          : "Optimisation de portefeuille et gestion des risques",
    },
    {
      name: language === "en" ? "Trading" : "Trading",
      icon: PieChart,
      description:
        language === "en"
          ? "Day trading, hedging strategies, and market analysis"
          : "Day trading, stratégies de couverture et analyse de marché",
    },
    {
      name: language === "en" ? "Forecasting" : "Prévisions",
      icon: TrendingUp,
      description:
        language === "en"
          ? "Financial projections, trend analysis, and predictive modeling"
          : "Projections financières, analyse de tendances et modélisation prédictive",
    },
    {
      name: language === "en" ? "Data Analysis" : "Analyse de Données",
      icon: Database,
      description:
        language === "en"
          ? "Data processing, visualization, and interpretation"
          : "Traitement, visualisation et interprétation des données",
    },
    {
      name: language === "en" ? "Cash Flow Management" : "Gestion de Trésorerie",
      icon: DollarSign,
      description:
        language === "en"
          ? "Optimizing cash flow, liquidity analysis, and working capital management"
          : "Optimisation des flux de trésorerie, analyse de liquidité et gestion du fonds de roulement",
    },
    {
      name: language === "en" ? "Financial Reporting" : "Reporting Financier",
      icon: FileText,
      description:
        language === "en"
          ? "Creating comprehensive financial reports and presentations"
          : "Création de rapports financiers complets et présentations",
    },
    {
      name: language === "en" ? "Budget Development" : "Développement Budgétaire",
      icon: Calculator,
      description:
        language === "en"
          ? "Creating and managing budgets exceeding $100,000"
          : "Création et gestion de budgets dépassant 100 000 $",
    },
    {
      name: language === "en" ? "Financial Modeling" : "Modélisation Financière",
      icon: ChartBar,
      description:
        language === "en"
          ? "Building complex financial models for analysis and decision-making"
          : "Construction de modèles financiers complexes pour l'analyse et la prise de décision",
    },
    {
      name: language === "en" ? "Banking & Finance" : "Banque et Finance",
      icon: Landmark,
      description:
        language === "en"
          ? "Understanding of banking systems, financial instruments, and markets"
          : "Compréhension des systèmes bancaires, instruments financiers et marchés",
    },
  ]

  const softSkills = [
    {
      name: language === "en" ? "Bilingual (English & French)" : "Bilingue (Anglais et Français)",
      icon: Globe,
      description: language === "en" ? "Fluent in both languages" : "Maîtrise des deux langues",
    },
    {
      name: language === "en" ? "Leadership" : "Leadership",
      icon: Briefcase,
      description:
        language === "en" ? "Team management and strategic direction" : "Gestion d'équipe et direction stratégique",
    },
    {
      name: language === "en" ? "Problem Solving" : "Résolution de Problèmes",
      icon: Calculator,
      description:
        language === "en" ? "Analytical thinking and creative solutions" : "Pensée analytique et solutions créatives",
    },
    {
      name: language === "en" ? "Teamwork" : "Travail d'Équipe",
      icon: Briefcase,
      description:
        language === "en" ? "Collaboration and effective communication" : "Collaboration et communication efficace",
    },
    {
      name: language === "en" ? "Time Management" : "Gestion du Temps",
      icon: Calculator,
      description: language === "en" ? "Prioritization and deadline management" : "Priorisation et gestion des délais",
    },
    {
      name: language === "en" ? "Adaptability" : "Adaptabilité",
      icon: PenTool,
      description:
        language === "en" ? "Flexibility in changing environments" : "Flexibilité dans des environnements changeants",
    },
  ]

  const certifications = [
    {
      name: language === "en" ? "Secret Clearance" : "Habilitation Secrète",
      icon: Shield,
      description: language === "en" ? "Government of Canada" : "Gouvernement du Canada",
    },
    {
      name:
        language === "en"
          ? "Microsoft Finance and Investment Program"
          : "Programme Finance et Investissement Microsoft",
      icon: BookOpen,
      description: language === "en" ? "Coursera - In Progress" : "Coursera - En Cours",
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="skills" className="py-20 bg-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-primary/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold text-gray-900">{t("skills.title")}</h2>
          <div className="mt-2 h-1 w-20 bg-primary mx-auto"></div>
          <p className="mt-4 text-gray-700 max-w-2xl mx-auto">{t("skills.description")}</p>
        </motion.div>

        <Tabs defaultValue="technical" value={activeTab} onValueChange={setActiveTab} className="max-w-5xl mx-auto">
          <div className="flex justify-center mb-10">
            <TabsList className="grid grid-cols-3 w-[500px]">
              <TabsTrigger value="technical">{t("skills.technical")}</TabsTrigger>
              <TabsTrigger value="soft">{t("skills.soft")}</TabsTrigger>
              <TabsTrigger value="certifications">{t("skills.certifications")}</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="technical" className="mt-0">
            <motion.div
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {technicalSkills.map((skill, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <Card className="border-none shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 h-full">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-3">
                        <div className="bg-primary/10 p-2 rounded-full mr-3">
                          <skill.icon className="h-5 w-5 text-primary" />
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900">{skill.name}</h3>
                      </div>
                      <p className="text-gray-600 text-sm">{skill.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          <TabsContent value="soft" className="mt-0">
            <motion.div
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {softSkills.map((skill, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <Card className="border-none shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 h-full">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-3">
                        <div className="bg-primary/10 p-2 rounded-full mr-3">
                          <skill.icon className="h-5 w-5 text-primary" />
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900">{skill.name}</h3>
                      </div>
                      <p className="text-gray-600 text-sm">{skill.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          <TabsContent value="certifications" className="mt-0">
            <motion.div
              className="grid md:grid-cols-2 gap-6"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {certifications.map((cert, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <Card className="border-none shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 h-full">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-3">
                        <div className="bg-primary/10 p-2 rounded-full mr-3">
                          <cert.icon className="h-5 w-5 text-primary" />
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900">{cert.name}</h3>
                      </div>
                      <p className="text-gray-600 text-sm">{cert.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}

