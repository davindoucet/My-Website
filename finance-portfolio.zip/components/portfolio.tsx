"use client"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calculator, TrendingUp, PieChart, BarChart } from "lucide-react"
import { motion } from "framer-motion"
import LoanCalculator from "@/components/projects/loan-calculator"
import InvestmentCalculator from "@/components/projects/investment-calculator"
import BudgetTracker from "@/components/projects/budget-tracker"
import StockAnalyzer from "@/components/projects/stock-analyzer"
import { useLanguage } from "@/contexts/language-context"
import LoanCalculatorFr from "@/components/projects/loan-calculator-fr"
import InvestmentCalculatorFr from "@/components/projects/investment-calculator-fr"
import BudgetTrackerFr from "@/components/projects/budget-tracker-fr"
import StockAnalyzerFr from "@/components/projects/stock-analyzer-fr"
import RetirementCalculator from "@/components/projects/retirement-calculator"
import TaxCalculator from "@/components/projects/tax-calculator"

export default function Portfolio() {
  const { t, language } = useLanguage()

  const projects = [
    {
      id: 1,
      title: language === "en" ? "Loan Calculator" : "Calculateur de Prêt",
      description:
        language === "en"
          ? "Calculate loan payments, interest, and amortization schedules."
          : "Calculez les paiements de prêt, les intérêts et les calendriers d'amortissement.",
      icon: Calculator,
      category: "calculator",
      component: language === "en" ? LoanCalculator : LoanCalculatorFr,
    },
    {
      id: 2,
      title: language === "en" ? "Investment Return Calculator" : "Calculateur de Rendement d'Investissement",
      description:
        language === "en"
          ? "Project future investment returns with compound interest."
          : "Projetez les rendements futurs des investissements avec intérêts composés.",
      icon: TrendingUp,
      category: "calculator",
      component: language === "en" ? InvestmentCalculator : InvestmentCalculatorFr,
    },
    {
      id: 3,
      title: language === "en" ? "Budget Tracker" : "Suivi Budgétaire",
      description:
        language === "en"
          ? "Track income and expenses with visual breakdowns."
          : "Suivez les revenus et les dépenses avec des analyses visuelles.",
      icon: PieChart,
      category: "tracker",
      component: language === "en" ? BudgetTracker : BudgetTrackerFr,
    },
    {
      id: 4,
      title: language === "en" ? "Stock Portfolio Analyzer" : "Analyseur de Portefeuille d'Actions",
      description:
        language === "en"
          ? "Analyze stock performance and portfolio diversification."
          : "Analysez la performance des actions et la diversification du portefeuille.",
      icon: BarChart,
      category: "analyzer",
      component: language === "en" ? StockAnalyzer : StockAnalyzerFr,
    },
    {
      id: 5,
      title: language === "en" ? "Retirement Calculator" : "Calculateur de Retraite",
      description:
        language === "en"
          ? "Plan your retirement savings and estimate future income."
          : "Planifiez votre épargne-retraite et estimez vos revenus futurs.",
      icon: Calculator,
      category: "calculator",
      component: RetirementCalculator,
    },
    {
      id: 6,
      title: language === "en" ? "Tax Calculator" : "Calculateur d'Impôt",
      description:
        language === "en"
          ? "Estimate income taxes and understand tax brackets."
          : "Estimez les impôts sur le revenu et comprenez les tranches d'imposition.",
      icon: Calculator,
      category: "calculator",
      component: TaxCalculator,
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  // Filter projects by category
  const calculatorProjects = projects.filter((project) => project.category === "calculator")
  const trackerProjects = projects.filter((project) => project.category === "tracker")
  const analyzerProjects = projects.filter((project) => project.category === "analyzer")

  return (
    <section id="portfolio" className="py-20 bg-gray-50 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-primary/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-gray-900">{t("portfolio.title")}</h2>
          <div className="mt-2 h-1 w-20 bg-primary mx-auto"></div>
          <p className="mt-4 text-gray-700 max-w-2xl mx-auto">{t("portfolio.description")}</p>
        </motion.div>

        <Tabs defaultValue="all" className="mb-12">
          <div className="flex justify-center">
            <TabsList>
              <TabsTrigger value="all">{t("portfolio.all")}</TabsTrigger>
              <TabsTrigger value="calculator">{t("portfolio.calculators")}</TabsTrigger>
              <TabsTrigger value="tracker">{t("portfolio.trackers")}</TabsTrigger>
              <TabsTrigger value="analyzer">{t("portfolio.analyzers")}</TabsTrigger>
            </TabsList>
          </div>

          {/* All Projects Tab */}
          <TabsContent value="all">
            <motion.div
              className="grid md:grid-cols-2 gap-8"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {projects.map((project) => (
                <motion.div key={project.id} variants={itemVariants}>
                  <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow duration-300 h-full dark:bg-gray-800">
                    <CardContent className="p-0">
                      <div className="p-6">
                        <div className="flex items-center mb-4">
                          <div className="bg-primary/10 p-3 rounded-full mr-4">
                            <project.icon className="h-6 w-6 text-primary" />
                          </div>
                          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{project.title}</h3>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 mb-6">{project.description}</p>
                        <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-6">
                          <project.component />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          {/* Calculators Tab */}
          <TabsContent value="calculator">
            <motion.div
              className="grid md:grid-cols-2 gap-8"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {calculatorProjects.map((project) => (
                <motion.div key={project.id} variants={itemVariants}>
                  <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow duration-300 h-full dark:bg-gray-800">
                    <CardContent className="p-0">
                      <div className="p-6">
                        <div className="flex items-center mb-4">
                          <div className="bg-primary/10 p-3 rounded-full mr-4">
                            <project.icon className="h-6 w-6 text-primary" />
                          </div>
                          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{project.title}</h3>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 mb-6">{project.description}</p>
                        <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-6">
                          <project.component />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          {/* Trackers Tab */}
          <TabsContent value="tracker">
            <motion.div
              className="grid md:grid-cols-1 gap-8"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {trackerProjects.map((project) => (
                <motion.div key={project.id} variants={itemVariants}>
                  <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow duration-300 h-full dark:bg-gray-800">
                    <CardContent className="p-0">
                      <div className="p-6">
                        <div className="flex items-center mb-4">
                          <div className="bg-primary/10 p-3 rounded-full mr-4">
                            <project.icon className="h-6 w-6 text-primary" />
                          </div>
                          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{project.title}</h3>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 mb-6">{project.description}</p>
                        <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-6">
                          <project.component />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          {/* Analyzers Tab */}
          <TabsContent value="analyzer">
            <motion.div
              className="grid md:grid-cols-1 gap-8"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {analyzerProjects.map((project) => (
                <motion.div key={project.id} variants={itemVariants}>
                  <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow duration-300 h-full dark:bg-gray-800">
                    <CardContent className="p-0">
                      <div className="p-6">
                        <div className="flex items-center mb-4">
                          <div className="bg-primary/10 p-3 rounded-full mr-4">
                            <project.icon className="h-6 w-6 text-primary" />
                          </div>
                          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{project.title}</h3>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 mb-6">{project.description}</p>
                        <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-6">
                          <project.component />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}

