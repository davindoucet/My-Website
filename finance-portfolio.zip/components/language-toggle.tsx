"use client"

import { useLanguage } from "@/contexts/language-context"
import { motion } from "framer-motion"

export default function LanguageToggle() {
  const { language, toggleLanguage } = useLanguage()

  return (
    <motion.button
      onClick={toggleLanguage}
      className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors duration-200"
      whileTap={{ scale: 0.9 }}
      whileHover={{ scale: 1.1 }}
      aria-label={language === "en" ? "Switch to French" : "Switch to English"}
    >
      <span className="font-bold text-sm">{language === "en" ? "FR" : "EN"}</span>
    </motion.button>
  )
}

