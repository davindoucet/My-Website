"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Trash2, TrendingUp, TrendingDown } from "lucide-react"

type Stock = {
  id: string
  ticker: string
  name: string
  price: number
  shares: number
  purchasePrice: number
  sector: string
}

const initialStocks: Stock[] = [
  {
    id: "1",
    ticker: "AAPL",
    name: "Apple Inc.",
    price: 175.25,
    shares: 10,
    purchasePrice: 150.75,
    sector: "Technology",
  },
  {
    id: "2",
    ticker: "MSFT",
    name: "Microsoft Corp.",
    price: 325.5,
    shares: 5,
    purchasePrice: 290.25,
    sector: "Technology",
  },
  {
    id: "3",
    ticker: "JNJ",
    name: "Johnson & Johnson",
    price: 160.75,
    shares: 8,
    purchasePrice: 155.5,
    sector: "Healthcare",
  },
  {
    id: "4",
    ticker: "JPM",
    name: "JPMorgan Chase & Co.",
    price: 145.3,
    shares: 12,
    purchasePrice: 130.8,
    sector: "Financial",
  },
]

const sectors = [
  "Technology",
  "Healthcare",
  "Financial",
  "Consumer",
  "Energy",
  "Industrial",
  "Utilities",
  "Real Estate",
]

export default function StockAnalyzer() {
  const [stocks, setStocks] = useState<Stock[]>(initialStocks)
  const [newStock, setNewStock] = useState<Omit<Stock, "id">>({
    ticker: "",
    name: "",
    price: 0,
    shares: 0,
    purchasePrice: 0,
    sector: "Technology",
  })

  const addStock = () => {
    if (newStock.ticker && newStock.name && newStock.price > 0 && newStock.shares > 0) {
      setStocks([
        ...stocks,
        {
          ...newStock,
          id: Date.now().toString(),
        },
      ])
      setNewStock({
        ticker: "",
        name: "",
        price: 0,
        shares: 0,
        purchasePrice: 0,
        sector: "Technology",
      })
    }
  }

  const deleteStock = (id: string) => {
    setStocks(stocks.filter((s) => s.id !== id))
  }

  // Calculate portfolio metrics
  const totalValue = stocks.reduce((sum, stock) => sum + stock.price * stock.shares, 0)
  const totalCost = stocks.reduce((sum, stock) => sum + stock.purchasePrice * stock.shares, 0)
  const totalGainLoss = totalValue - totalCost
  const totalGainLossPercent = totalCost > 0 ? (totalGainLoss / totalCost) * 100 : 0

  // Calculate sector allocation
  const sectorAllocation = stocks.reduce(
    (acc, stock) => {
      const value = stock.price * stock.shares
      acc[stock.sector] = (acc[stock.sector] || 0) + value
      return acc
    },
    {} as Record<string, number>,
  )

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <h4 className="text-sm font-medium text-gray-500">Portfolio Value</h4>
            <p className="text-2xl font-bold text-gray-900">${totalValue.toFixed(2)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h4 className="text-sm font-medium text-gray-500">Total Gain/Loss</h4>
            <div className="flex items-center">
              <p className={`text-2xl font-bold ${totalGainLoss >= 0 ? "text-green-600" : "text-red-600"}`}>
                ${totalGainLoss.toFixed(2)}
              </p>
              <span className={`ml-2 flex items-center ${totalGainLoss >= 0 ? "text-green-600" : "text-red-600"}`}>
                {totalGainLoss >= 0 ? (
                  <TrendingUp className="h-4 w-4 mr-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 mr-1" />
                )}
                {Math.abs(totalGainLossPercent).toFixed(2)}%
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h4 className="text-sm font-medium text-gray-500">Number of Stocks</h4>
            <p className="text-2xl font-bold text-gray-900">{stocks.length}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Card>
            <CardContent className="p-4">
              <h4 className="text-lg font-semibold mb-4">Add Stock</h4>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="ticker">Ticker Symbol</Label>
                    <Input
                      id="ticker"
                      value={newStock.ticker}
                      onChange={(e) =>
                        setNewStock({
                          ...newStock,
                          ticker: e.target.value.toUpperCase(),
                        })
                      }
                      placeholder="e.g. AAPL"
                    />
                  </div>

                  <div>
                    <Label htmlFor="name">Company Name</Label>
                    <Input
                      id="name"
                      value={newStock.name}
                      onChange={(e) =>
                        setNewStock({
                          ...newStock,
                          name: e.target.value,
                        })
                      }
                      placeholder="e.g. Apple Inc."
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="price">Current Price</Label>
                    <Input
                      id="price"
                      type="number"
                      value={newStock.price || ""}
                      onChange={(e) =>
                        setNewStock({
                          ...newStock,
                          price: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      placeholder="e.g. 150.75"
                    />
                  </div>

                  <div>
                    <Label htmlFor="purchasePrice">Purchase Price</Label>
                    <Input
                      id="purchasePrice"
                      type="number"
                      value={newStock.purchasePrice || ""}
                      onChange={(e) =>
                        setNewStock({
                          ...newStock,
                          purchasePrice: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      placeholder="e.g. 145.50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="shares">Number of Shares</Label>
                    <Input
                      id="shares"
                      type="number"
                      value={newStock.shares || ""}
                      onChange={(e) =>
                        setNewStock({
                          ...newStock,
                          shares: Number.parseInt(e.target.value) || 0,
                        })
                      }
                      placeholder="e.g. 10"
                    />
                  </div>

                  <div>
                    <Label htmlFor="sector">Sector</Label>
                    <select
                      id="sector"
                      value={newStock.sector}
                      onChange={(e) =>
                        setNewStock({
                          ...newStock,
                          sector: e.target.value,
                        })
                      }
                      className="w-full mt-1 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"
                    >
                      {sectors.map((sector) => (
                        <option key={sector} value={sector}>
                          {sector}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <Button onClick={addStock} className="w-full">
                  <PlusCircle className="h-4 w-4 mr-2" /> Add Stock
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Tabs defaultValue="portfolio">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
              <TabsTrigger value="analysis">Analysis</TabsTrigger>
            </TabsList>

            <TabsContent value="portfolio" className="mt-4">
              <div className="max-h-64 overflow-y-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Ticker
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Shares
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Price
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Value
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        G/L
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {stocks.map((stock) => {
                      const value = stock.price * stock.shares
                      const cost = stock.purchasePrice * stock.shares
                      const gainLoss = value - cost
                      const gainLossPercent = (gainLoss / cost) * 100

                      return (
                        <tr key={stock.id}>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">{stock.ticker}</div>
                            <div className="text-xs text-gray-500">{stock.name}</div>
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">{stock.shares}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                            ${stock.price.toFixed(2)}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">${value.toFixed(2)}</td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <div className={`text-sm ${gainLoss >= 0 ? "text-green-600" : "text-red-600"}`}>
                              ${gainLoss.toFixed(2)}
                            </div>
                            <div
                              className={`text-xs flex items-center ${gainLoss >= 0 ? "text-green-600" : "text-red-600"}`}
                            >
                              {gainLoss >= 0 ? (
                                <TrendingUp className="h-3 w-3 mr-1" />
                              ) : (
                                <TrendingDown className="h-3 w-3 mr-1" />
                              )}
                              {Math.abs(gainLossPercent).toFixed(2)}%
                            </div>
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                            <Button variant="ghost" size="sm" onClick={() => deleteStock(stock.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="analysis" className="mt-4">
              <div className="h-64 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col space-y-2">
                  <h4 className="text-sm font-semibold mb-2">Sector Allocation</h4>
                  {Object.entries(sectorAllocation).map(([sector, value]) => (
                    <div key={sector} className="flex items-center">
                      <div
                        className="w-4 h-4 rounded-full mr-2"
                        style={{ backgroundColor: getSectorColor(sector) }}
                      ></div>
                      <div className="flex-1">{sector}</div>
                      <div className="font-medium">${value.toFixed(2)}</div>
                      <div className="text-gray-500 text-sm ml-2">({((value / totalValue) * 100).toFixed(1)}%)</div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-center">
                  <div className="relative w-40 h-40">
                    <svg viewBox="0 0 100 100" className="w-full h-full">
                      {renderPieChart(sectorAllocation, totalValue)}
                    </svg>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

// Helper function to get a color for a sector
function getSectorColor(sector: string): string {
  const colors: Record<string, string> = {
    Technology: "#3b82f6",
    Healthcare: "#8b5cf6",
    Financial: "#f59e0b",
    Consumer: "#10b981",
    Energy: "#ef4444",
    Industrial: "#6b7280",
    Utilities: "#14b8a6",
    "Real Estate": "#ec4899",
  }

  return colors[sector] || "#6b7280"
}

// Helper function to render a pie chart
function renderPieChart(data: Record<string, number>, total: number) {
  let currentAngle = 0
  const centerX = 50
  const centerY = 50
  const radius = 40

  return Object.entries(data).map(([sector, value]) => {
    const percentage = value / total
    const angleSize = percentage * 360
    const startAngle = currentAngle
    const endAngle = currentAngle + angleSize
    currentAngle = endAngle

    const startX = centerX + radius * Math.cos((startAngle * Math.PI) / 180)
    const startY = centerY + radius * Math.sin((startAngle * Math.PI) / 180)
    const endX = centerX + radius * Math.cos((endAngle * Math.PI) / 180)
    const endY = centerY + radius * Math.sin((endAngle * Math.PI) / 180)

    const largeArcFlag = angleSize > 180 ? 1 : 0

    const pathData = [
      `M ${centerX} ${centerY}`,
      `L ${startX} ${startY}`,
      `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX} ${endY}`,
      "Z",
    ].join(" ")

    return <path key={sector} d={pathData} fill={getSectorColor(sector)} stroke="#fff" strokeWidth="1" />
  })
}

