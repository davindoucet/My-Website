"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { useLanguage } from "@/contexts/language-context"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { HelpCircle, Printer } from "lucide-react"

// Tax brackets for US and Canada (simplified)
const taxBrackets = {
  US: [
    { min: 0, max: 11000, rate: 10 },
    { min: 11001, max: 44725, rate: 12 },
    { min: 44726, max: 95375, rate: 22 },
    { min: 95376, max: 182100, rate: 24 },
    { min: 182101, max: 231250, rate: 32 },
    { min: 231251, max: 578125, rate: 35 },
    { min: 578126, max: Number.POSITIVE_INFINITY, rate: 37 },
  ],
  Canada: [
    { min: 0, max: 53359, rate: 15 },
    { min: 53360, max: 106717, rate: 20.5 },
    { min: 106718, max: 165430, rate: 26 },
    { min: 165431, max: 235675, rate: 29 },
    { min: 235676, max: Number.POSITIVE_INFINITY, rate: 33 },
  ],
}

export default function TaxCalculator() {
  const { language } = useLanguage()
  const [country, setCountry] = useState<"US" | "Canada">("US")
  const [income, setIncome] = useState(75000)
  const [deductions, setDeductions] = useState(12950) // Standard deduction
  const [filingStatus, setFilingStatus] = useState("single")
  const [showDetailedBreakdown, setShowDetailedBreakdown] = useState(false)
  const [results, setResults] = useState<{
    taxableIncome: number
    totalTax: number
    effectiveRate: number
    marginalRate: number
    afterTaxIncome: number
    brackets: Array<{
      min: number
      max: number
      rate: number
      taxAmount: number
    }>
  } | null>(null)

  const calculateTax = () => {
    const taxableIncome = Math.max(0, income - deductions)
    let totalTax = 0
    let marginalRate = 0

    // Calculate tax by bracket
    const brackets = taxBrackets[country].map((bracket) => {
      if (taxableIncome <= bracket.min) {
        return { ...bracket, taxAmount: 0 }
      }

      const taxableInBracket = Math.min(taxableIncome, bracket.max) - bracket.min
      if (taxableInBracket > 0) {
        marginalRate = bracket.rate
      }

      const taxAmount = Math.max(0, taxableInBracket * (bracket.rate / 100))
      totalTax += taxAmount

      return {
        ...bracket,
        taxAmount,
      }
    })

    const effectiveRate = taxableIncome > 0 ? (totalTax / taxableIncome) * 100 : 0
    const afterTaxIncome = income - totalTax

    setResults({
      taxableIncome,
      totalTax,
      effectiveRate,
      marginalRate,
      afterTaxIncome,
      brackets,
    })
  }

  // Save data to localStorage
  const saveData = () => {
    const data = {
      country,
      income,
      deductions,
      filingStatus,
      results,
    }
    localStorage.setItem("taxCalculator", JSON.stringify(data))
    alert(language === "en" ? "Data saved successfully!" : "Données sauvegardées avec succès!")
  }

  // Load data from localStorage
  const loadData = () => {
    const savedData = localStorage.getItem("taxCalculator")
    if (savedData) {
      const data = JSON.parse(savedData)
      setCountry(data.country)
      setIncome(data.income)
      setDeductions(data.deductions)
      setFilingStatus(data.filingStatus)
      setResults(data.results)
      alert(language === "en" ? "Data loaded successfully!" : "Données chargées avec succès!")
    } else {
      alert(language === "en" ? "No saved data found!" : "Aucune donnée sauvegardée trouvée!")
    }
  }

  // Print results
  const printResults = () => {
    if (!results) return

    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    const html = `
      <html>
        <head>
          <title>${language === "en" ? "Tax Calculator Results" : "Résultats du calculateur d'impôt"}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #9c6644; }
            .summary { margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .tax-bracket { background-color: #f9f9f9; }
          </style>
        </head>
        <body>
          <h1>${language === "en" ? "Tax Calculator Results" : "Résultats du calculateur d'impôt"}</h1>
          <div class="summary">
            <p><strong>${language === "en" ? "Country" : "Pays"}:</strong> ${country}</p>
            <p><strong>${language === "en" ? "Filing Status" : "Statut de déclaration"}:</strong> ${filingStatus}</p>
            <p><strong>${language === "en" ? "Gross Income" : "Revenu brut"}:</strong> $${income.toLocaleString()}</p>
            <p><strong>${language === "en" ? "Deductions" : "Déductions"}:</strong> $${deductions.toLocaleString()}</p>
            <p><strong>${language === "en" ? "Taxable Income" : "Revenu imposable"}:</strong> $${results.taxableIncome.toLocaleString()}</p>
          </div>
          
          <h2>${language === "en" ? "Results" : "Résultats"}</h2>
          <p><strong>${language === "en" ? "Total Tax" : "Impôt total"}:</strong> $${results.totalTax.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
          <p><strong>${language === "en" ? "After-Tax Income" : "Revenu après impôt"}:</strong> $${results.afterTaxIncome.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
          <p><strong>${language === "en" ? "Effective Tax Rate" : "Taux d'imposition effectif"}:</strong> ${results.effectiveRate.toFixed(2)}%</p>
          <p><strong>${language === "en" ? "Marginal Tax Rate" : "Taux d'imposition marginal"}:</strong> ${results.marginalRate.toFixed(2)}%</p>
          
          <h2>${language === "en" ? "Tax Bracket Breakdown" : "Répartition par tranche d'imposition"}</h2>
          <table>
            <thead>
              <tr>
                <th>${language === "en" ? "Bracket" : "Tranche"}</th>
                <th>${language === "en" ? "Rate" : "Taux"}</th>
                <th>${language === "en" ? "Taxable Amount" : "Montant imposable"}</th>
                <th>${language === "en" ? "Tax" : "Impôt"}</th>
              </tr>
            </thead>
            <tbody>
              ${results.brackets
                .filter((b) => b.taxAmount > 0)
                .map(
                  (bracket) => `
                <tr>
                  <td>$${bracket.min.toLocaleString()} - $${bracket.max === Number.POSITIVE_INFINITY ? (language === "en" ? "and up" : "et plus") : bracket.max.toLocaleString()}</td>
                  <td>${bracket.rate}%</td>
                  <td>$${(Math.min(results.taxableIncome, bracket.max) - bracket.min).toLocaleString()}</td>
                  <td>$${bracket.taxAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
                </tr>
              `,
                )
                .join("")}
              <tr>
                <td colspan="3"><strong>${language === "en" ? "Total Tax" : "Impôt total"}</strong></td>
                <td><strong>$${results.totalTax.toLocaleString(undefined, { maximumFractionDigits: 2 })}</strong></td>
              </tr>
            </tbody>
          </table>
        </body>
      </html>
    `

    printWindow.document.write(html)
    printWindow.document.close()
    printWindow.print()
  }

  return (
    <div className="p-4 bg-white dark:bg-gray-900 rounded-lg">
      <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">
        {language === "en" ? "Income Tax Calculator" : "Calculateur d'impôt sur le revenu"}
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="space-y-4">
            <div>
              <Label htmlFor="country" className="mb-2 block">
                {language === "en" ? "Country" : "Pays"}
              </Label>
              <select
                id="country"
                value={country}
                onChange={(e) => setCountry(e.target.value as "US" | "Canada")}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              >
                <option value="US">{language === "en" ? "United States" : "États-Unis"}</option>
                <option value="Canada">Canada</option>
              </select>
            </div>

            <div>
              <Label htmlFor="filingStatus" className="mb-2 block">
                {language === "en" ? "Filing Status" : "Statut de déclaration"}
              </Label>
              <select
                id="filingStatus"
                value={filingStatus}
                onChange={(e) => setFilingStatus(e.target.value)}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              >
                <option value="single">{language === "en" ? "Single" : "Célibataire"}</option>
                <option value="married">{language === "en" ? "Married" : "Marié(e)"}</option>
                <option value="head">{language === "en" ? "Head of Household" : "Chef de famille"}</option>
              </select>
            </div>

            <div>
              <div className="flex items-center">
                <Label htmlFor="income" className="mr-2">
                  {language === "en" ? "Gross Income" : "Revenu brut"}
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en"
                        ? "Your total income before taxes and deductions"
                        : "Votre revenu total avant impôts et déductions"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Input
                id="income"
                type="number"
                value={income}
                onChange={(e) => setIncome(Number(e.target.value))}
                className="mt-1 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div>
              <div className="flex items-center">
                <Label htmlFor="deductions" className="mr-2">
                  {language === "en" ? "Deductions" : "Déductions"}
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en"
                        ? "Standard deduction or itemized deductions"
                        : "Déduction standard ou déductions détaillées"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Input
                id="deductions"
                type="number"
                value={deductions}
                onChange={(e) => setDeductions(Number(e.target.value))}
                className="mt-1 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="showDetailedBreakdown"
                checked={showDetailedBreakdown}
                onCheckedChange={setShowDetailedBreakdown}
              />
              <Label htmlFor="showDetailedBreakdown">
                {language === "en" ? "Show detailed breakdown" : "Afficher la répartition détaillée"}
              </Label>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mt-6">
            <Button onClick={calculateTax} className="bg-primary hover:bg-primary/90">
              {language === "en" ? "Calculate" : "Calculer"}
            </Button>
            <Button onClick={saveData} variant="outline" className="border-primary text-primary hover:bg-primary/10">
              {language === "en" ? "Save Data" : "Sauvegarder les données"}
            </Button>
            <Button onClick={loadData} variant="outline" className="border-primary text-primary hover:bg-primary/10">
              {language === "en" ? "Load Data" : "Charger les données"}
            </Button>
            {results && (
              <Button
                onClick={printResults}
                variant="outline"
                className="border-primary text-primary hover:bg-primary/10"
              >
                <Printer className="h-4 w-4 mr-2" />
                {language === "en" ? "Print" : "Imprimer"}
              </Button>
            )}
          </div>
        </div>

        <div>
          {results && (
            <Card>
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                  {language === "en" ? "Tax Summary" : "Résumé fiscal"}
                </h4>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {language === "en" ? "Gross Income" : "Revenu brut"}
                      </p>
                      <p className="text-lg font-medium text-gray-900 dark:text-white">${income.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {language === "en" ? "Taxable Income" : "Revenu imposable"}
                      </p>
                      <p className="text-lg font-medium text-gray-900 dark:text-white">
                        ${results.taxableIncome.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {language === "en" ? "Total Tax" : "Impôt total"}
                      </p>
                      <p className="text-lg font-medium text-primary">
                        ${results.totalTax.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {language === "en" ? "After-Tax Income" : "Revenu après impôt"}
                      </p>
                      <p className="text-lg font-medium text-green-600 dark:text-green-500">
                        ${results.afterTaxIncome.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {language === "en" ? "Effective Tax Rate" : "Taux d'imposition effectif"}
                      </p>
                      <p className="text-lg font-medium text-gray-900 dark:text-white">
                        {results.effectiveRate.toFixed(2)}%
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {language === "en" ? "Marginal Tax Rate" : "Taux d'imposition marginal"}
                      </p>
                      <p className="text-lg font-medium text-gray-900 dark:text-white">{results.marginalRate}%</p>
                    </div>
                  </div>

                  {showDetailedBreakdown && (
                    <div className="mt-6">
                      <h5 className="text-md font-semibold mb-2 text-gray-900 dark:text-white">
                        {language === "en" ? "Tax Bracket Breakdown" : "Répartition par tranche d'imposition"}
                      </h5>
                      <div className="max-h-60 overflow-y-auto">
                        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                          <thead className="bg-gray-100 dark:bg-gray-800">
                            <tr>
                              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                {language === "en" ? "Bracket" : "Tranche"}
                              </th>
                              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                {language === "en" ? "Rate" : "Taux"}
                              </th>
                              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                {language === "en" ? "Tax" : "Impôt"}
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                            {results.brackets
                              .filter((b) => b.taxAmount > 0)
                              .map((bracket, index) => (
                                <tr key={index} className="tax-bracket">
                                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                    ${bracket.min.toLocaleString()} - $
                                    {bracket.max === Number.POSITIVE_INFINITY
                                      ? language === "en"
                                        ? "and up"
                                        : "et plus"
                                      : bracket.max.toLocaleString()}
                                  </td>
                                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                    {bracket.rate}%
                                  </td>
                                  <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                    ${bracket.taxAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                                  </td>
                                </tr>
                              ))}
                            <tr>
                              <td
                                colSpan={2}
                                className="px-3 py-2 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white"
                              >
                                {language === "en" ? "Total Tax" : "Impôt total"}
                              </td>
                              <td className="px-3 py-2 whitespace-nowrap text-sm font-bold text-primary">
                                ${results.totalTax.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  <div className="mt-4">
                    <div className="w-full h-8 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary"
                        style={{ width: `${Math.min(100, results.effectiveRate * 3)}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between mt-1 text-xs text-gray-500 dark:text-gray-400">
                      <span>0%</span>
                      <span>10%</span>
                      <span>20%</span>
                      <span>30%</span>
                      <span>40%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

