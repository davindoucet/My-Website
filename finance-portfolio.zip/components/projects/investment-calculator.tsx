"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"

export default function InvestmentCalculator() {
  const [initialInvestment, setInitialInvestment] = useState(10000)
  const [monthlyContribution, setMonthlyContribution] = useState(500)
  const [annualReturn, setAnnualReturn] = useState(8)
  const [investmentPeriod, setInvestmentPeriod] = useState(20)
  const [compoundFrequency, setCompoundFrequency] = useState("monthly")
  const [inflationAdjusted, setInflationAdjusted] = useState(false)
  const [results, setResults] = useState<{
    futureValue: number
    totalContributions: number
    totalInterest: number
    yearlyData: Array<{
      year: number
      balance: number
      contributions: number
      interest: number
      inflationAdjustedBalance?: number
    }>
  } | null>(null)

  const calculateInvestment = () => {
    const inflation = inflationAdjusted ? 2.5 : 0 // Assume 2.5% inflation
    const realReturn = annualReturn - inflation

    let compoundsPerYear = 12 // Default to monthly
    if (compoundFrequency === "daily") compoundsPerYear = 365
    if (compoundFrequency === "quarterly") compoundsPerYear = 4
    if (compoundFrequency === "annually") compoundsPerYear = 1

    const periodicRate = realReturn / 100 / compoundsPerYear
    const totalPeriods = investmentPeriod * compoundsPerYear

    let balance = initialInvestment
    let totalContributions = initialInvestment
    const yearlyData = []

    for (let year = 1; year <= investmentPeriod; year++) {
      let yearlyContributions = 0
      let yearlyInterest = 0

      for (let i = 1; i <= compoundsPerYear; i++) {
        const interest = balance * periodicRate
        balance += interest + monthlyContribution
        yearlyContributions += monthlyContribution
        yearlyInterest += interest
      }

      totalContributions += yearlyContributions

      yearlyData.push({
        year,
        balance,
        contributions: yearlyContributions,
        interest: yearlyInterest,
        inflationAdjustedBalance: inflationAdjusted ? balance / Math.pow(1 + inflation / 100, year) : undefined,
      })
    }

    setResults({
      futureValue: balance,
      totalContributions,
      totalInterest: balance - totalContributions,
      yearlyData,
    })
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="mb-4">
            <Label htmlFor="initialInvestment">Initial Investment: ${initialInvestment.toLocaleString()}</Label>
            <Slider
              id="initialInvestment"
              min={0}
              max={100000}
              step={1000}
              value={[initialInvestment]}
              onValueChange={(value) => setInitialInvestment(value[0])}
              className="my-2"
            />
            <Input
              type="number"
              value={initialInvestment}
              onChange={(e) => setInitialInvestment(Number(e.target.value))}
              className="mt-1"
            />
          </div>

          <div className="mb-4">
            <Label htmlFor="monthlyContribution">Monthly Contribution: ${monthlyContribution}</Label>
            <Slider
              id="monthlyContribution"
              min={0}
              max={5000}
              step={100}
              value={[monthlyContribution]}
              onValueChange={(value) => setMonthlyContribution(value[0])}
              className="my-2"
            />
            <Input
              type="number"
              value={monthlyContribution}
              onChange={(e) => setMonthlyContribution(Number(e.target.value))}
              className="mt-1"
            />
          </div>

          <div className="mb-4">
            <Label htmlFor="annualReturn">Annual Return: {annualReturn}%</Label>
            <Slider
              id="annualReturn"
              min={0}
              max={20}
              step={0.5}
              value={[annualReturn]}
              onValueChange={(value) => setAnnualReturn(value[0])}
              className="my-2"
            />
            <Input
              type="number"
              value={annualReturn}
              onChange={(e) => setAnnualReturn(Number(e.target.value))}
              step="0.5"
              className="mt-1"
            />
          </div>

          <div className="mb-4">
            <Label htmlFor="investmentPeriod">Investment Period: {investmentPeriod} years</Label>
            <Slider
              id="investmentPeriod"
              min={1}
              max={50}
              step={1}
              value={[investmentPeriod]}
              onValueChange={(value) => setInvestmentPeriod(value[0])}
              className="my-2"
            />
            <Input
              type="number"
              value={investmentPeriod}
              onChange={(e) => setInvestmentPeriod(Number(e.target.value))}
              className="mt-1"
            />
          </div>

          <div className="mb-4">
            <Label htmlFor="compoundFrequency">Compound Frequency</Label>
            <select
              id="compoundFrequency"
              value={compoundFrequency}
              onChange={(e) => setCompoundFrequency(e.target.value)}
              className="w-full mt-1 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"
            >
              <option value="daily">Daily</option>
              <option value="monthly">Monthly</option>
              <option value="quarterly">Quarterly</option>
              <option value="annually">Annually</option>
            </select>
          </div>

          <div className="flex items-center space-x-2 mb-4">
            <Switch id="inflationAdjusted" checked={inflationAdjusted} onCheckedChange={setInflationAdjusted} />
            <Label htmlFor="inflationAdjusted">Adjust for inflation (2.5%)</Label>
          </div>

          <Button onClick={calculateInvestment} className="w-full mt-2">
            Calculate
          </Button>
        </div>

        <div>
          {results && (
            <Card>
              <CardContent className="p-4">
                <h4 className="text-lg font-semibold mb-4">Investment Summary</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Future Value:</span>
                    <span className="font-medium">${results.futureValue.toFixed(2)}</span>
                  </div>
                  {inflationAdjusted && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Inflation-Adjusted Value:</span>
                      <span className="font-medium">
                        ${results.yearlyData[results.yearlyData.length - 1].inflationAdjustedBalance?.toFixed(2)}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Contributions:</span>
                    <span className="font-medium">${results.totalContributions.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Interest:</span>
                    <span className="font-medium">${results.totalInterest.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {results && (
        <div className="mt-6">
          <Tabs defaultValue="chart">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="chart">Growth Chart</TabsTrigger>
              <TabsTrigger value="table">Yearly Breakdown</TabsTrigger>
            </TabsList>
            <TabsContent value="chart" className="mt-4">
              <div className="h-64 relative">
                <div className="absolute inset-0 flex items-end">
                  <div
                    className="bg-primary/80 h-full w-1/2 rounded-tl-md rounded-bl-md flex items-center justify-center text-white font-medium"
                    style={{ height: `${(results.totalContributions / results.futureValue) * 100}%` }}
                  >
                    Contributions
                    <br />${results.totalContributions.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </div>
                  <div
                    className="bg-primary/40 h-full w-1/2 rounded-tr-md rounded-br-md flex items-center justify-center text-white font-medium"
                    style={{ height: `${(results.totalInterest / results.futureValue) * 100}%` }}
                  >
                    Interest
                    <br />${results.totalInterest.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="table" className="mt-4">
              <div className="max-h-64 overflow-y-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Year
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Balance
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Contributions
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Interest
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {results.yearlyData.map((row) => (
                      <tr key={row.year}>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">{row.year}</td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                          ${row.balance.toFixed(0)}
                          {inflationAdjusted && (
                            <span className="text-xs text-gray-400 block">
                              (${row.inflationAdjustedBalance?.toFixed(0)} adj.)
                            </span>
                          )}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                          ${row.contributions.toFixed(0)}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">
                          ${row.interest.toFixed(0)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  )
}

