"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Trash2 } from "lucide-react"

type Transaction = {
  id: string
  description: string
  amount: number
  type: "income" | "expense"
  category: string
}

const initialCategories = {
  income: ["Salaire", "Investissements", "Freelance", "Autre"],
  expense: ["Logement", "Alimentation", "Transport", "Divertissement", "Services", "Autre"],
}

export default function BudgetTrackerFr() {
  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: "1", description: "Salaire mensuel", amount: 5000, type: "income", category: "Salaire" },
    { id: "2", description: "Loyer", amount: 1500, type: "expense", category: "Logement" },
    { id: "3", description: "Épicerie", amount: 400, type: "expense", category: "Alimentation" },
    { id: "4", description: "Dividende", amount: 200, type: "income", category: "Investissements" },
  ])

  const [newTransaction, setNewTransaction] = useState<Omit<Transaction, "id">>({
    description: "",
    amount: 0,
    type: "expense",
    category: "Logement",
  })

  const addTransaction = () => {
    if (newTransaction.description && newTransaction.amount > 0) {
      setTransactions([
        ...transactions,
        {
          ...newTransaction,
          id: Date.now().toString(),
        },
      ])
      setNewTransaction({
        description: "",
        amount: 0,
        type: "expense",
        category: "Logement",
      })
    }
  }

  const deleteTransaction = (id: string) => {
    setTransactions(transactions.filter((t) => t.id !== id))
  }

  const totalIncome = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

  const totalExpenses = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

  const balance = totalIncome - totalExpenses

  // Calculate category totals for the pie chart
  const incomeByCategory = transactions
    .filter((t) => t.type === "income")
    .reduce(
      (acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount
        return acc
      },
      {} as Record<string, number>,
    )

  const expensesByCategory = transactions
    .filter((t) => t.type === "expense")
    .reduce(
      (acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount
        return acc
      },
      {} as Record<string, number>,
    )

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className={`border-l-4 ${balance >= 0 ? "border-l-green-500" : "border-l-red-500"}`}>
          <CardContent className="p-4">
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Solde</h4>
            <p
              className={`text-2xl font-bold ${balance >= 0 ? "text-green-600 dark:text-green-500" : "text-red-600 dark:text-red-500"}`}
            >
              ${balance.toFixed(2)}
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Revenus</h4>
            <p className="text-2xl font-bold text-green-600 dark:text-green-500">${totalIncome.toFixed(2)}</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-500">
          <CardContent className="p-4">
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Dépenses</h4>
            <p className="text-2xl font-bold text-red-600 dark:text-red-500">${totalExpenses.toFixed(2)}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Card>
            <CardContent className="p-4">
              <h4 className="text-lg font-semibold mb-4">Ajouter une transaction</h4>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="type">Type</Label>
                  <select
                    id="type"
                    value={newTransaction.type}
                    onChange={(e) =>
                      setNewTransaction({
                        ...newTransaction,
                        type: e.target.value as "income" | "expense",
                        category: e.target.value === "income" ? "Salaire" : "Logement",
                      })
                    }
                    className="w-full mt-1 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  >
                    <option value="income">Revenu</option>
                    <option value="expense">Dépense</option>
                  </select>
                </div>

                <div>
                  <Label htmlFor="category">Catégorie</Label>
                  <select
                    id="category"
                    value={newTransaction.category}
                    onChange={(e) =>
                      setNewTransaction({
                        ...newTransaction,
                        category: e.target.value,
                      })
                    }
                    className="w-full mt-1 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  >
                    {initialCategories[newTransaction.type].map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={newTransaction.description}
                    onChange={(e) =>
                      setNewTransaction({
                        ...newTransaction,
                        description: e.target.value,
                      })
                    }
                    placeholder="Entrez une description"
                    className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  />
                </div>

                <div>
                  <Label htmlFor="amount">Montant</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={newTransaction.amount || ""}
                    onChange={(e) =>
                      setNewTransaction({
                        ...newTransaction,
                        amount: Number.parseFloat(e.target.value) || 0,
                      })
                    }
                    placeholder="Entrez un montant"
                    className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  />
                </div>

                <Button onClick={addTransaction} className="w-full">
                  <PlusCircle className="h-4 w-4 mr-2" /> Ajouter une transaction
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Tabs defaultValue="all">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">Tout</TabsTrigger>
              <TabsTrigger value="income">Revenus</TabsTrigger>
              <TabsTrigger value="expense">Dépenses</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-4">
              <div className="max-h-64 overflow-y-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-100 dark:bg-gray-800">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Description
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Catégorie
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Montant
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"></th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                    {transactions.map((transaction) => (
                      <tr key={transaction.id}>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {transaction.description}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {transaction.category}
                        </td>
                        <td
                          className={`px-3 py-2 whitespace-nowrap text-sm ${transaction.type === "income" ? "text-green-600 dark:text-green-500" : "text-red-600 dark:text-red-500"}`}
                        >
                          {transaction.type === "income" ? "+" : "-"}${transaction.amount.toFixed(2)}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          <Button variant="ghost" size="sm" onClick={() => deleteTransaction(transaction.id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="income" className="mt-4">
              <div className="max-h-64 overflow-y-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-100 dark:bg-gray-800">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Description
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Catégorie
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Montant
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"></th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                    {transactions
                      .filter((t) => t.type === "income")
                      .map((transaction) => (
                        <tr key={transaction.id}>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {transaction.description}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {transaction.category}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-green-600 dark:text-green-500">
                            +${transaction.amount.toFixed(2)}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            <Button variant="ghost" size="sm" onClick={() => deleteTransaction(transaction.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="expense" className="mt-4">
              <div className="max-h-64 overflow-y-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-100 dark:bg-gray-800">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Description
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Catégorie
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Montant
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"></th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                    {transactions
                      .filter((t) => t.type === "expense")
                      .map((transaction) => (
                        <tr key={transaction.id}>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {transaction.description}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {transaction.category}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-red-600 dark:text-red-500">
                            -${transaction.amount.toFixed(2)}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            <Button variant="ghost" size="sm" onClick={() => deleteTransaction(transaction.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <div className="mt-6">
        <Tabs defaultValue="income">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="income">Répartition des revenus</TabsTrigger>
            <TabsTrigger value="expense">Répartition des dépenses</TabsTrigger>
          </TabsList>

          <TabsContent value="income" className="mt-4">
            <div className="h-64 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col space-y-2">
                {Object.entries(incomeByCategory).map(([category, amount]) => (
                  <div key={category} className="flex items-center">
                    <div
                      className="w-4 h-4 rounded-full mr-2"
                      style={{ backgroundColor: getColorForCategory(category) }}
                    ></div>
                    <div className="flex-1">{category}</div>
                    <div className="font-medium">${amount.toFixed(2)}</div>
                    <div className="text-gray-500 dark:text-gray-400 text-sm ml-2">
                      ({((amount / totalIncome) * 100).toFixed(1)}%)
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-center">
                <div className="relative w-40 h-40">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    {renderPieChart(incomeByCategory, totalIncome)}
                  </svg>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="expense" className="mt-4">
            <div className="h-64 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col space-y-2">
                {Object.entries(expensesByCategory).map(([category, amount]) => (
                  <div key={category} className="flex items-center">
                    <div
                      className="w-4 h-4 rounded-full mr-2"
                      style={{ backgroundColor: getColorForCategory(category) }}
                    ></div>
                    <div className="flex-1">{category}</div>
                    <div className="font-medium">${amount.toFixed(2)}</div>
                    <div className="text-gray-500 dark:text-gray-400 text-sm ml-2">
                      ({((amount / totalExpenses) * 100).toFixed(1)}%)
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-center">
                <div className="relative w-40 h-40">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    {renderPieChart(expensesByCategory, totalExpenses)}
                  </svg>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Helper function to get a color for a category
function getColorForCategory(category: string): string {
  const colors: Record<string, string> = {
    Salaire: "#4ade80",
    Investissements: "#22c55e",
    Freelance: "#16a34a",
    Logement: "#ef4444",
    Alimentation: "#f97316",
    Transport: "#f59e0b",
    Divertissement: "#3b82f6",
    Services: "#8b5cf6",
    Autre: "#6b7280",
  }

  return colors[category] || "#6b7280"
}

// Helper function to render a pie chart
function renderPieChart(data: Record<string, number>, total: number) {
  let currentAngle = 0
  const centerX = 50
  const centerY = 50
  const radius = 40

  return Object.entries(data).map(([category, amount]) => {
    const percentage = amount / total
    const angleSize = percentage * 360
    const startAngle = currentAngle
    const endAngle = currentAngle + angleSize
    currentAngle = endAngle

    const startX = centerX + radius * Math.cos((startAngle * Math.PI) / 180)
    const startY = centerY + radius * Math.sin((startAngle * Math.PI) / 180)
    const endX = centerX + radius * Math.cos((endAngle * Math.PI) / 180)
    const endY = centerY + radius * Math.sin((endAngle * Math.PI) / 180)

    const largeArcFlag = angleSize > 180 ? 1 : 0

    const pathData = [
      `M ${centerX} ${centerY}`,
      `L ${startX} ${startY}`,
      `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX} ${endY}`,
      "Z",
    ].join(" ")

    return <path key={category} d={pathData} fill={getColorForCategory(category)} stroke="#fff" strokeWidth="1" />
  })
}

