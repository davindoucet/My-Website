"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function LoanCalculatorFr() {
  const [loanAmount, setLoanAmount] = useState(100000)
  const [interestRate, setInterestRate] = useState(5)
  const [loanTerm, setLoanTerm] = useState(30)
  const [results, setResults] = useState<{
    monthlyPayment: number
    totalPayment: number
    totalInterest: number
    amortization: Array<{
      month: number
      payment: number
      principal: number
      interest: number
      balance: number
    }>
  } | null>(null)

  const calculateLoan = () => {
    const monthlyRate = interestRate / 100 / 12
    const numberOfPayments = loanTerm * 12
    const monthlyPayment =
      (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) /
      (Math.pow(1 + monthlyRate, numberOfPayments) - 1)

    const totalPayment = monthlyPayment * numberOfPayments
    const totalInterest = totalPayment - loanAmount

    // Calculate amortization schedule
    let balance = loanAmount
    const amortization = []

    for (let month = 1; month <= numberOfPayments; month++) {
      const interestPayment = balance * monthlyRate
      const principalPayment = monthlyPayment - interestPayment
      balance -= principalPayment

      amortization.push({
        month,
        payment: monthlyPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance: balance > 0 ? balance : 0,
      })
    }

    setResults({
      monthlyPayment,
      totalPayment,
      totalInterest,
      amortization,
    })
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="mb-4">
            <Label htmlFor="loanAmount">Montant du prêt: ${loanAmount.toLocaleString()}</Label>
            <Slider
              id="loanAmount"
              min={1000}
              max={1000000}
              step={1000}
              value={[loanAmount]}
              onValueChange={(value) => setLoanAmount(value[0])}
              className="my-2"
            />
            <Input
              type="number"
              value={loanAmount}
              onChange={(e) => setLoanAmount(Number(e.target.value))}
              className="mt-1"
            />
          </div>

          <div className="mb-4">
            <Label htmlFor="interestRate">Taux d'intérêt: {interestRate}%</Label>
            <Slider
              id="interestRate"
              min={0.1}
              max={20}
              step={0.1}
              value={[interestRate]}
              onValueChange={(value) => setInterestRate(value[0])}
              className="my-2"
            />
            <Input
              type="number"
              value={interestRate}
              onChange={(e) => setInterestRate(Number(e.target.value))}
              step="0.1"
              className="mt-1"
            />
          </div>

          <div className="mb-4">
            <Label htmlFor="loanTerm">Durée du prêt: {loanTerm} ans</Label>
            <Slider
              id="loanTerm"
              min={1}
              max={40}
              step={1}
              value={[loanTerm]}
              onValueChange={(value) => setLoanTerm(value[0])}
              className="my-2"
            />
            <Input
              type="number"
              value={loanTerm}
              onChange={(e) => setLoanTerm(Number(e.target.value))}
              className="mt-1"
            />
          </div>

          <Button onClick={calculateLoan} className="w-full mt-2">
            Calculer
          </Button>
        </div>

        <div>
          {results && (
            <Card>
              <CardContent className="p-4">
                <h4 className="text-lg font-semibold mb-4">Résumé du prêt</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Paiement mensuel:</span>
                    <span className="font-medium">${results.monthlyPayment.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Paiement total:</span>
                    <span className="font-medium">${results.totalPayment.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Intérêt total:</span>
                    <span className="font-medium">${results.totalInterest.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {results && (
        <div className="mt-6">
          <Tabs defaultValue="chart">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="chart">Graphique de paiement</TabsTrigger>
              <TabsTrigger value="schedule">Calendrier d'amortissement</TabsTrigger>
            </TabsList>
            <TabsContent value="chart" className="mt-4">
              <div className="h-64 relative">
                <div className="absolute inset-0 flex items-end">
                  <div
                    className="bg-primary/80 h-full w-1/2 rounded-tl-md rounded-bl-md flex items-center justify-center text-white font-medium"
                    style={{ height: `${(results.loanAmount / results.totalPayment) * 100}%` }}
                  >
                    Principal
                    <br />${loanAmount.toLocaleString()}
                  </div>
                  <div
                    className="bg-primary/40 h-full w-1/2 rounded-tr-md rounded-br-md flex items-center justify-center text-white font-medium"
                    style={{ height: `${(results.totalInterest / results.totalPayment) * 100}%` }}
                  >
                    Intérêt
                    <br />${results.totalInterest.toFixed(0)}
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="schedule" className="mt-4">
              <div className="max-h-64 overflow-y-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-100 dark:bg-gray-800">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Mois
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Paiement
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Principal
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Intérêt
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Solde
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                    {results.amortization.slice(0, 12).map((row) => (
                      <tr key={row.month}>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {row.month}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          ${row.payment.toFixed(2)}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          ${row.principal.toFixed(2)}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          ${row.interest.toFixed(2)}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          ${row.balance.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  )
}

