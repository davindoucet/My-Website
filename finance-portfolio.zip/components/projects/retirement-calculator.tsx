"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { useLanguage } from "@/contexts/language-context"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { HelpCircle } from "lucide-react"

export default function RetirementCalculator() {
  const { language } = useLanguage()
  const [currentAge, setCurrentAge] = useState(30)
  const [retirementAge, setRetirementAge] = useState(65)
  const [currentSavings, setCurrentSavings] = useState(50000)
  const [annualContribution, setAnnualContribution] = useState(6000)
  const [expectedReturn, setExpectedReturn] = useState(7)
  const [inflationRate, setInflationRate] = useState(2.5)
  const [adjustForInflation, setAdjustForInflation] = useState(true)
  const [withdrawalRate, setWithdrawalRate] = useState(4)
  const [results, setResults] = useState<{
    futureValue: number
    annualIncome: number
    inflationAdjustedValue: number
    inflationAdjustedIncome: number
    yearlyData: Array<{
      age: number
      savings: number
      contributions: number
      interest: number
      inflationAdjustedSavings?: number
    }>
  } | null>(null)

  const calculateRetirement = () => {
    const yearsToRetirement = retirementAge - currentAge
    const realReturn = expectedReturn - (adjustForInflation ? inflationRate : 0)

    let savings = currentSavings
    const yearlyData = []

    for (let year = 1; year <= yearsToRetirement; year++) {
      const interest = savings * (realReturn / 100)
      const contribution =
        year === 1
          ? annualContribution
          : annualContribution * Math.pow(1 + (adjustForInflation ? inflationRate : 0) / 100, year - 1)

      savings += interest + contribution

      yearlyData.push({
        age: currentAge + year,
        savings,
        contributions: contribution,
        interest,
        inflationAdjustedSavings: adjustForInflation ? savings : savings / Math.pow(1 + inflationRate / 100, year),
      })
    }

    const futureValue = savings
    const annualIncome = futureValue * (withdrawalRate / 100)
    const inflationAdjustedValue = adjustForInflation
      ? futureValue
      : futureValue / Math.pow(1 + inflationRate / 100, yearsToRetirement)
    const inflationAdjustedIncome = inflationAdjustedValue * (withdrawalRate / 100)

    setResults({
      futureValue,
      annualIncome,
      inflationAdjustedValue,
      inflationAdjustedIncome,
      yearlyData,
    })
  }

  // Save data to localStorage
  const saveData = () => {
    const data = {
      currentAge,
      retirementAge,
      currentSavings,
      annualContribution,
      expectedReturn,
      inflationRate,
      adjustForInflation,
      withdrawalRate,
      results,
    }
    localStorage.setItem("retirementCalculator", JSON.stringify(data))
    alert(language === "en" ? "Data saved successfully!" : "Données sauvegardées avec succès!")
  }

  // Load data from localStorage
  const loadData = () => {
    const savedData = localStorage.getItem("retirementCalculator")
    if (savedData) {
      const data = JSON.parse(savedData)
      setCurrentAge(data.currentAge)
      setRetirementAge(data.retirementAge)
      setCurrentSavings(data.currentSavings)
      setAnnualContribution(data.annualContribution)
      setExpectedReturn(data.expectedReturn)
      setInflationRate(data.inflationRate)
      setAdjustForInflation(data.adjustForInflation)
      setWithdrawalRate(data.withdrawalRate)
      setResults(data.results)
      alert(language === "en" ? "Data loaded successfully!" : "Données chargées avec succès!")
    } else {
      alert(language === "en" ? "No saved data found!" : "Aucune donnée sauvegardée trouvée!")
    }
  }

  // Print results
  const printResults = () => {
    if (!results) return

    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    const html = `
      <html>
        <head>
          <title>${language === "en" ? "Retirement Calculator Results" : "Résultats du calculateur de retraite"}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #9c6644; }
            .summary { margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
          </style>
        </head>
        <body>
          <h1>${language === "en" ? "Retirement Calculator Results" : "Résultats du calculateur de retraite"}</h1>
          <div class="summary">
            <p><strong>${language === "en" ? "Current Age" : "Âge actuel"}:</strong> ${currentAge}</p>
            <p><strong>${language === "en" ? "Retirement Age" : "Âge de retraite"}:</strong> ${retirementAge}</p>
            <p><strong>${language === "en" ? "Current Savings" : "Épargne actuelle"}:</strong> $${currentSavings.toLocaleString()}</p>
            <p><strong>${language === "en" ? "Annual Contribution" : "Contribution annuelle"}:</strong> $${annualContribution.toLocaleString()}</p>
            <p><strong>${language === "en" ? "Expected Return" : "Rendement attendu"}:</strong> ${expectedReturn}%</p>
            <p><strong>${language === "en" ? "Inflation Rate" : "Taux d'inflation"}:</strong> ${inflationRate}%</p>
            <p><strong>${language === "en" ? "Withdrawal Rate" : "Taux de retrait"}:</strong> ${withdrawalRate}%</p>
          </div>
          
          <h2>${language === "en" ? "Results" : "Résultats"}</h2>
          <p><strong>${language === "en" ? "Retirement Savings" : "Épargne de retraite"}:</strong> $${results.futureValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          <p><strong>${language === "en" ? "Annual Retirement Income" : "Revenu annuel de retraite"}:</strong> $${results.annualIncome.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          <p><strong>${language === "en" ? "Inflation-Adjusted Savings" : "Épargne ajustée à l'inflation"}:</strong> $${results.inflationAdjustedValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          <p><strong>${language === "en" ? "Inflation-Adjusted Income" : "Revenu ajusté à l'inflation"}:</strong> $${results.inflationAdjustedIncome.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
          
          <h2>${language === "en" ? "Year by Year Breakdown" : "Répartition année par année"}</h2>
          <table>
            <thead>
              <tr>
                <th>${language === "en" ? "Age" : "Âge"}</th>
                <th>${language === "en" ? "Savings" : "Épargne"}</th>
                <th>${language === "en" ? "Contribution" : "Contribution"}</th>
                <th>${language === "en" ? "Interest" : "Intérêt"}</th>
                ${adjustForInflation ? `<th>${language === "en" ? "Inflation-Adjusted" : "Ajusté à l'inflation"}</th>` : ""}
              </tr>
            </thead>
            <tbody>
              ${results.yearlyData
                .map(
                  (year) => `
                <tr>
                  <td>${year.age}</td>
                  <td>$${year.savings.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td>$${year.contributions.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td>$${year.interest.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  ${adjustForInflation ? `<td>$${year.inflationAdjustedSavings?.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>` : ""}
                </tr>
              `,
                )
                .join("")}
            </tbody>
          </table>
        </body>
      </html>
    `

    printWindow.document.write(html)
    printWindow.document.close()
    printWindow.print()
  }

  return (
    <div className="p-4 bg-white dark:bg-gray-900 rounded-lg">
      <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">
        {language === "en" ? "Retirement Calculator" : "Calculateur de retraite"}
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="space-y-4">
            <div>
              <div className="flex items-center">
                <Label htmlFor="currentAge" className="mr-2">
                  {language === "en" ? "Current Age" : "Âge actuel"}: {currentAge}
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en" ? "Your current age in years" : "Votre âge actuel en années"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Slider
                id="currentAge"
                min={18}
                max={80}
                step={1}
                value={[currentAge]}
                onValueChange={(value) => setCurrentAge(value[0])}
                className="my-2"
              />
            </div>

            <div>
              <div className="flex items-center">
                <Label htmlFor="retirementAge" className="mr-2">
                  {language === "en" ? "Retirement Age" : "Âge de retraite"}: {retirementAge}
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en"
                        ? "The age at which you plan to retire"
                        : "L'âge auquel vous prévoyez de prendre votre retraite"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Slider
                id="retirementAge"
                min={currentAge + 1}
                max={90}
                step={1}
                value={[retirementAge]}
                onValueChange={(value) => setRetirementAge(value[0])}
                className="my-2"
              />
            </div>

            <div>
              <div className="flex items-center">
                <Label htmlFor="currentSavings" className="mr-2">
                  {language === "en" ? "Current Savings" : "Épargne actuelle"}: ${currentSavings.toLocaleString()}
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en"
                        ? "Your current retirement savings balance"
                        : "Votre solde d'épargne-retraite actuel"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Slider
                id="currentSavings"
                min={0}
                max={1000000}
                step={1000}
                value={[currentSavings]}
                onValueChange={(value) => setCurrentSavings(value[0])}
                className="my-2"
              />
              <Input
                type="number"
                value={currentSavings}
                onChange={(e) => setCurrentSavings(Number(e.target.value))}
                className="mt-1 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div>
              <div className="flex items-center">
                <Label htmlFor="annualContribution" className="mr-2">
                  {language === "en" ? "Annual Contribution" : "Contribution annuelle"}: $
                  {annualContribution.toLocaleString()}
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en"
                        ? "How much you plan to contribute each year"
                        : "Combien vous prévoyez de contribuer chaque année"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Slider
                id="annualContribution"
                min={0}
                max={50000}
                step={500}
                value={[annualContribution]}
                onValueChange={(value) => setAnnualContribution(value[0])}
                className="my-2"
              />
              <Input
                type="number"
                value={annualContribution}
                onChange={(e) => setAnnualContribution(Number(e.target.value))}
                className="mt-1 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>
          </div>
        </div>

        <div>
          <div className="space-y-4">
            <div>
              <div className="flex items-center">
                <Label htmlFor="expectedReturn" className="mr-2">
                  {language === "en" ? "Expected Return" : "Rendement attendu"}: {expectedReturn}%
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en"
                        ? "Annual rate of return on your investments"
                        : "Taux de rendement annuel de vos investissements"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Slider
                id="expectedReturn"
                min={1}
                max={12}
                step={0.1}
                value={[expectedReturn]}
                onValueChange={(value) => setExpectedReturn(value[0])}
                className="my-2"
              />
              <Input
                type="number"
                value={expectedReturn}
                onChange={(e) => setExpectedReturn(Number(e.target.value))}
                step="0.1"
                className="mt-1 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div>
              <div className="flex items-center">
                <Label htmlFor="inflationRate" className="mr-2">
                  {language === "en" ? "Inflation Rate" : "Taux d'inflation"}: {inflationRate}%
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en" ? "Expected annual inflation rate" : "Taux d'inflation annuel prévu"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Slider
                id="inflationRate"
                min={0}
                max={10}
                step={0.1}
                value={[inflationRate]}
                onValueChange={(value) => setInflationRate(value[0])}
                className="my-2"
              />
              <Input
                type="number"
                value={inflationRate}
                onChange={(e) => setInflationRate(Number(e.target.value))}
                step="0.1"
                className="mt-1 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div>
              <div className="flex items-center">
                <Label htmlFor="withdrawalRate" className="mr-2">
                  {language === "en" ? "Withdrawal Rate" : "Taux de retrait"}: {withdrawalRate}%
                </Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-500" />
                    </TooltipTrigger>
                    <TooltipContent>
                      {language === "en"
                        ? "Percentage of savings you plan to withdraw annually during retirement"
                        : "Pourcentage d'épargne que vous prévoyez de retirer annuellement pendant la retraite"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Slider
                id="withdrawalRate"
                min={1}
                max={10}
                step={0.1}
                value={[withdrawalRate]}
                onValueChange={(value) => setWithdrawalRate(value[0])}
                className="my-2"
              />
              <Input
                type="number"
                value={withdrawalRate}
                onChange={(e) => setWithdrawalRate(Number(e.target.value))}
                step="0.1"
                className="mt-1 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="adjustForInflation" checked={adjustForInflation} onCheckedChange={setAdjustForInflation} />
              <Label htmlFor="adjustForInflation">
                {language === "en" ? "Adjust for inflation" : "Ajuster pour l'inflation"}
              </Label>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <HelpCircle className="h-4 w-4 text-gray-500" />
                  </TooltipTrigger>
                  <TooltipContent>
                    {language === "en"
                      ? "Calculate results in today's dollars"
                      : "Calculer les résultats en dollars d'aujourd'hui"}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mt-6">
        <Button onClick={calculateRetirement} className="bg-primary hover:bg-primary/90">
          {language === "en" ? "Calculate" : "Calculer"}
        </Button>
        <Button onClick={saveData} variant="outline" className="border-primary text-primary hover:bg-primary/10">
          {language === "en" ? "Save Data" : "Sauvegarder les données"}
        </Button>
        <Button onClick={loadData} variant="outline" className="border-primary text-primary hover:bg-primary/10">
          {language === "en" ? "Load Data" : "Charger les données"}
        </Button>
        {results && (
          <Button onClick={printResults} variant="outline" className="border-primary text-primary hover:bg-primary/10">
            {language === "en" ? "Print Results" : "Imprimer les résultats"}
          </Button>
        )}
      </div>

      {results && (
        <div className="mt-8">
          <Card className="mb-6">
            <CardContent className="p-6">
              <h4 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                {language === "en" ? "Retirement Summary" : "Résumé de la retraite"}
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-700 dark:text-gray-300">
                    {language === "en" ? "Retirement Savings:" : "Épargne de retraite:"}
                  </p>
                  <p className="text-2xl font-bold text-primary">
                    ${results.futureValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {language === "en" ? "at age" : "à l'âge de"} {retirementAge}
                  </p>
                </div>
                <div>
                  <p className="text-gray-700 dark:text-gray-300">
                    {language === "en" ? "Annual Retirement Income:" : "Revenu annuel de retraite:"}
                  </p>
                  <p className="text-2xl font-bold text-primary">
                    ${results.annualIncome.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {language === "en" ? "based on" : "basé sur"} {withdrawalRate}%{" "}
                    {language === "en" ? "withdrawal rate" : "taux de retrait"}
                  </p>
                </div>
                {adjustForInflation && (
                  <>
                    <div>
                      <p className="text-gray-700 dark:text-gray-300">
                        {language === "en" ? "Inflation-Adjusted Savings:" : "Épargne ajustée à l'inflation:"}
                      </p>
                      <p className="text-2xl font-bold text-primary">
                        ${results.inflationAdjustedValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {language === "en" ? "in today's dollars" : "en dollars d'aujourd'hui"}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-700 dark:text-gray-300">
                        {language === "en" ? "Inflation-Adjusted Income:" : "Revenu ajusté à l'inflation:"}
                      </p>
                      <p className="text-2xl font-bold text-primary">
                        ${results.inflationAdjustedIncome.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {language === "en" ? "in today's dollars" : "en dollars d'aujourd'hui"}
                      </p>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="chart">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="chart">{language === "en" ? "Growth Chart" : "Graphique de croissance"}</TabsTrigger>
              <TabsTrigger value="table">{language === "en" ? "Year by Year" : "Année par année"}</TabsTrigger>
            </TabsList>

            <TabsContent value="chart" className="mt-4">
              <div className="h-80 relative">
                <svg viewBox="0 0 800 300" className="w-full h-full">
                  {/* X and Y axes */}
                  <line x1="50" y1="250" x2="750" y2="250" stroke="#888" strokeWidth="1" />
                  <line x1="50" y1="50" x2="50" y2="250" stroke="#888" strokeWidth="1" />

                  {/* X-axis labels */}
                  {results.yearlyData
                    .filter((_, i) => i % Math.ceil(results.yearlyData.length / 10) === 0)
                    .map((data, i, filtered) => (
                      <text
                        key={`x-${i}`}
                        x={50 + i * (700 / (filtered.length - 1 || 1))}
                        y="270"
                        textAnchor="middle"
                        fontSize="12"
                        fill="currentColor"
                        className="text-gray-600 dark:text-gray-400"
                      >
                        {data.age}
                      </text>
                    ))}

                  {/* Y-axis labels */}
                  {[0, 1, 2, 3, 4].map((i) => {
                    const value = Math.round((results.futureValue * i) / 4)
                    return (
                      <text
                        key={`y-${i}`}
                        x="45"
                        y={250 - i * 50}
                        textAnchor="end"
                        fontSize="12"
                        fill="currentColor"
                        className="text-gray-600 dark:text-gray-400"
                      >
                        ${value.toLocaleString(undefined, { notation: "compact", maximumFractionDigits: 1 })}
                      </text>
                    )
                  })}

                  {/* Plot line */}
                  <path
                    d={`M50,${250 - (currentSavings / results.futureValue) * 200} ${results.yearlyData
                      .map((data, i) => {
                        const x = 50 + (i + 1) * (700 / results.yearlyData.length)
                        const y = 250 - (data.savings / results.futureValue) * 200
                        return `L${x},${y}`
                      })
                      .join(" ")}`}
                    fill="none"
                    stroke="#9c6644"
                    strokeWidth="2"
                  />

                  {/* Inflation adjusted line if needed */}
                  {adjustForInflation && (
                    <path
                      d={`M50,${250 - (currentSavings / results.futureValue) * 200} ${results.yearlyData
                        .map((data, i) => {
                          const x = 50 + (i + 1) * (700 / results.yearlyData.length)
                          const y = 250 - ((data.inflationAdjustedSavings || 0) / results.futureValue) * 200
                          return `L${x},${y}`
                        })
                        .join(" ")}`}
                      fill="none"
                      stroke="#9c6644"
                      strokeWidth="2"
                      strokeDasharray="5,5"
                    />
                  )}
                </svg>

                <div className="absolute bottom-0 left-0 flex items-center">
                  <div className="flex items-center mr-4">
                    <div className="w-4 h-1 bg-primary mr-1"></div>
                    <span className="text-xs text-gray-600 dark:text-gray-400">
                      {language === "en" ? "Nominal Value" : "Valeur nominale"}
                    </span>
                  </div>
                  {adjustForInflation && (
                    <div className="flex items-center">
                      <div className="w-4 h-1 bg-primary mr-1" style={{ borderTop: "1px dashed" }}></div>
                      <span className="text-xs text-gray-600 dark:text-gray-400">
                        {language === "en" ? "Inflation-Adjusted" : "Ajusté à l'inflation"}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="table" className="mt-4">
              <div className="max-h-80 overflow-y-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-100 dark:bg-gray-800">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        {language === "en" ? "Age" : "Âge"}
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        {language === "en" ? "Savings" : "Épargne"}
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        {language === "en" ? "Contribution" : "Contribution"}
                      </th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        {language === "en" ? "Interest" : "Intérêt"}
                      </th>
                      {adjustForInflation && (
                        <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {language === "en" ? "Inflation-Adjusted" : "Ajusté à l'inflation"}
                        </th>
                      )}
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                    {results.yearlyData.map((year, index) => (
                      <tr key={index}>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {year.age}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          ${year.savings.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          ${year.contributions.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          ${year.interest.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        {adjustForInflation && (
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            ${year.inflationAdjustedSavings?.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  )
}

