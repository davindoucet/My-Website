"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { TrendingUp, TrendingDown } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

type StockData = {
  symbol: string
  price: number
  change: number
  changePercent: number
}

export default function StockTicker() {
  const { language } = useLanguage()
  const [stocks, setStocks] = useState<StockData[]>([
    { symbol: "AAPL", price: 175.25, change: 2.35, changePercent: 1.36 },
    { symbol: "MSFT", price: 325.5, change: -1.75, changePercent: -0.54 },
    { symbol: "GOOGL", price: 142.75, change: 0.85, changePercent: 0.6 },
    { symbol: "AMZN", price: 178.35, change: 3.25, changePercent: 1.86 },
    { symbol: "TSLA", price: 215.45, change: -4.2, changePercent: -1.91 },
  ])

  // Simulate price updates
  useEffect(() => {
    const interval = setInterval(() => {
      setStocks((prevStocks) =>
        prevStocks.map((stock) => {
          const changeAmount = (Math.random() * 2 - 1) * (stock.price * 0.005)
          const newPrice = Math.max(stock.price + changeAmount, 0.01)
          return {
            ...stock,
            price: Number.parseFloat(newPrice.toFixed(2)),
            change: Number.parseFloat((newPrice - stock.price + stock.change).toFixed(2)),
            changePercent: Number.parseFloat(
              (((newPrice - stock.price + stock.change) / (stock.price - stock.change)) * 100).toFixed(2),
            ),
          }
        }),
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="w-full bg-gray-100 dark:bg-gray-800 py-2 overflow-hidden">
      <div className="flex items-center space-x-8 animate-marquee">
        {stocks.map((stock) => (
          <div key={stock.symbol} className="flex items-center space-x-2 px-4">
            <span className="font-semibold text-gray-900 dark:text-white">{stock.symbol}</span>
            <span className="text-gray-700 dark:text-gray-300">${stock.price.toFixed(2)}</span>
            <AnimatePresence mode="wait">
              <motion.div
                key={`${stock.symbol}-${stock.change > 0 ? "up" : "down"}`}
                initial={{ opacity: 0, y: stock.change > 0 ? 10 : -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className={`flex items-center ${stock.change > 0 ? "text-green-600 dark:text-green-500" : "text-red-600 dark:text-red-500"}`}
              >
                {stock.change > 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                <span>
                  {stock.change > 0 ? "+" : ""}
                  {stock.change.toFixed(2)} ({stock.change > 0 ? "+" : ""}
                  {stock.changePercent.toFixed(2)}%)
                </span>
              </motion.div>
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  )
}

