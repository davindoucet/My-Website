"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Mail, Phone, MapPin, Send, Check, Loader2, Github, Linkedin, FileText } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import emailjs from "@emailjs/browser"
import { useLanguage } from "@/contexts/language-context"
import confetti from "canvas-confetti"

export default function Contact() {
  const formRef = useRef<HTMLFormElement>(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState("")
  const { t } = useLanguage()

  // Initialize EmailJS
  useEffect(() => {
    emailjs.init("SYRTHvjeWLapxz63t")
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    // Use EmailJS to send the form
    emailjs
      .sendForm(
        "service_p1p3lcj", // Service ID
        "template_ud06xzj", // Template ID
        formRef.current!,
        "SYRTHvjeWLapxz63t", // User ID
      )
      .then(
        (result) => {
          setIsSubmitting(false)
          setIsSubmitted(true)
          setFormData({
            name: "",
            email: "",
            subject: "",
            message: "",
          })

          // Trigger confetti animation
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
          })

          // Reset success message after 5 seconds
          setTimeout(() => {
            setIsSubmitted(false)
          }, 5000)
        },
        (error) => {
          setIsSubmitting(false)
          setError("Failed to send message. Please try again later.")
          console.error(error)
        },
      )
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section
      id="contact"
      className="py-20 bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 relative overflow-hidden"
    >
      {/* Decorative elements */}
      <div className="absolute top-20 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-0 w-80 h-80 bg-primary/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white">{t("contact.title")}</h2>
          <div className="mt-2 h-1 w-20 bg-primary mx-auto"></div>
          <p className="mt-4 text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">{t("contact.description")}</p>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <div className="md:col-span-1">
            <div className="space-y-6">
              <motion.div variants={itemVariants}>
                <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden dark:bg-gray-800">
                  <CardContent className="p-6 flex items-start space-x-4">
                    <div className="bg-primary/10 p-3 rounded-full">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">{t("contact.email")}</h3>
                      <p className="text-gray-700 dark:text-gray-300">davindoucet@hotmail.com</p>
                      <a href="mailto:davindoucet@hotmail.com" className="text-primary hover:underline text-sm">
                        {t("contact.email")}
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden dark:bg-gray-800">
                  <CardContent className="p-6 flex items-start space-x-4">
                    <div className="bg-primary/10 p-3 rounded-full">
                      <Phone className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">{t("contact.phone")}</h3>
                      <p className="text-gray-700 dark:text-gray-300">514-638-7382</p>
                      <a href="tel:5146387382" className="text-primary hover:underline text-sm">
                        Give me a call
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden dark:bg-gray-800">
                  <CardContent className="p-6 flex items-start space-x-4">
                    <div className="bg-primary/10 p-3 rounded-full">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">
                        {t("contact.location")}
                      </h3>
                      <p className="text-gray-700 dark:text-gray-300">Ottawa, ON</p>
                      <p className="text-gray-700 dark:text-gray-300">Canada</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden dark:bg-gray-800">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                      {t("contact.socialProfiles")}
                    </h3>
                    <div className="flex items-center space-x-4">
                      <a
                        href="https://www.linkedin.com/in/davin-doucet"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group"
                      >
                        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary/30 group-hover:border-primary transition-all duration-300 flex items-center justify-center bg-primary/10">
                          <Linkedin className="h-6 w-6 text-primary" />
                        </div>
                        <span className="block text-center text-xs mt-1 text-gray-600 dark:text-gray-400 group-hover:text-primary">
                          LinkedIn
                        </span>
                      </a>

                      <a
                        href="https://github.com/davindoucet"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group"
                      >
                        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary/30 group-hover:border-primary transition-all duration-300 flex items-center justify-center bg-primary/10">
                          <Github className="h-6 w-6 text-primary" />
                        </div>
                        <span className="block text-center text-xs mt-1 text-gray-600 dark:text-gray-400 group-hover:text-primary">
                          GitHub
                        </span>
                      </a>

                      <a href="/resume" className="group">
                        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary/30 group-hover:border-primary transition-all duration-300 flex items-center justify-center bg-primary/10">
                          <FileText className="h-6 w-6 text-primary" />
                        </div>
                        <span className="block text-center text-xs mt-1 text-gray-600 dark:text-gray-400 group-hover:text-primary">
                          Resume
                        </span>
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>

          <motion.div className="md:col-span-2" variants={itemVariants}>
            <Card className="border-none shadow-xl overflow-hidden dark:bg-gray-800">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">{t("contact.sendMessage")}</h3>

                <AnimatePresence mode="wait">
                  {isSubmitted ? (
                    <motion.div
                      className="bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800 rounded-lg p-6 flex flex-col items-center text-green-800 dark:text-green-400"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                    >
                      <div className="w-16 h-16 bg-green-100 dark:bg-green-800/50 rounded-full flex items-center justify-center mb-4">
                        <Check className="h-8 w-8 text-green-600 dark:text-green-400" />
                      </div>
                      <p className="text-center text-lg font-medium">{t("contact.success")}</p>
                    </motion.div>
                  ) : (
                    <motion.form
                      ref={formRef}
                      onSubmit={handleSubmit}
                      className="space-y-6"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="name" className="text-gray-700 dark:text-gray-300">
                            {t("contact.yourName")}
                          </Label>
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            placeholder="John Doe"
                            required
                            className="mt-1 border-gray-300 focus:border-primary focus:ring-primary dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          />
                        </div>
                        <div>
                          <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">
                            {t("contact.yourEmail")}
                          </Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleChange}
                            placeholder="john.doe@example.com"
                            required
                            className="mt-1 border-gray-300 focus:border-primary focus:ring-primary dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="subject" className="text-gray-700 dark:text-gray-300">
                          {t("contact.subject")}
                        </Label>
                        <Input
                          id="subject"
                          name="subject"
                          value={formData.subject}
                          onChange={handleChange}
                          placeholder="How can I help you?"
                          required
                          className="mt-1 border-gray-300 focus:border-primary focus:ring-primary dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        />
                      </div>

                      <div>
                        <Label htmlFor="message" className="text-gray-700 dark:text-gray-300">
                          {t("contact.message")}
                        </Label>
                        <Textarea
                          id="message"
                          name="message"
                          value={formData.message}
                          onChange={handleChange}
                          placeholder="Your message here..."
                          required
                          className="mt-1 min-h-[150px] border-gray-300 focus:border-primary focus:ring-primary dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        />
                      </div>

                      {error && (
                        <div className="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-lg p-3 text-red-800 dark:text-red-400 text-sm">
                          {error}
                        </div>
                      )}

                      <Button
                        type="submit"
                        className="w-full bg-primary hover:bg-primary/90 text-white py-6 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <span className="flex items-center justify-center">
                            <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                            {t("contact.sending")}
                          </span>
                        ) : (
                          <span className="flex items-center justify-center">
                            <Send className="h-5 w-5 mr-2" />
                            {t("contact.send")}
                          </span>
                        )}
                      </Button>
                    </motion.form>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

