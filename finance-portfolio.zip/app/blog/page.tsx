"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { useLanguage } from "@/contexts/language-context"
import { ArrowRight, Calendar, Clock, Tag } from "lucide-react"

// Sample blog data
const blogPosts = [
  {
    id: 1,
    title: {
      en: "Understanding Market Volatility: A Guide for New Investors",
      fr: "Comprendre la volatilité du marché : Un guide pour les nouveaux investisseurs",
    },
    excerpt: {
      en: "Market volatility can be intimidating for new investors. This guide explains what causes market fluctuations and how to build a resilient portfolio.",
      fr: "La volatilité du marché peut être intimidante pour les nouveaux investisseurs. Ce guide explique les causes des fluctuations du marché et comment construire un portefeuille résilient.",
    },
    date: "2023-12-15",
    readTime: 8,
    category: {
      en: "Investing",
      fr: "Investissement",
    },
    image: "/placeholder.svg?height=400&width=600",
    content: {
      en: `
        <p>Market volatility is a term used to describe the frequency and magnitude of price movements in financial markets. For new investors, these fluctuations can seem random and frightening, but understanding the underlying causes can help you navigate uncertain times with confidence.</p>
        
        <h2>What Causes Market Volatility?</h2>
        
        <p>Several factors contribute to market volatility:</p>
        
        <ul>
          <li><strong>Economic Data Releases:</strong> Information about inflation, employment, GDP growth, and other economic indicators can trigger market movements.</li>
          <li><strong>Central Bank Policies:</strong> Changes in interest rates or monetary policy can significantly impact market sentiment.</li>
          <li><strong>Geopolitical Events:</strong> Wars, trade disputes, elections, and other political developments create uncertainty.</li>
          <li><strong>Corporate Earnings:</strong> Companies reporting results that differ from expectations can cause price swings.</li>
          <li><strong>Market Sentiment:</strong> Fear, greed, and other emotions can drive irrational market behavior.</li>
        </ul>
        
        <h2>Building a Resilient Portfolio</h2>
        
        <p>Here are strategies to help you manage volatility:</p>
        
        <ol>
          <li><strong>Diversification:</strong> Spread investments across different asset classes, sectors, and geographic regions.</li>
          <li><strong>Long-Term Perspective:</strong> Focus on your investment goals rather than short-term market movements.</li>
          <li><strong>Dollar-Cost Averaging:</strong> Invest regularly regardless of market conditions to reduce the impact of volatility.</li>
          <li><strong>Emergency Fund:</strong> Maintain liquid assets to avoid selling investments during market downturns.</li>
          <li><strong>Risk Assessment:</strong> Understand your risk tolerance and adjust your portfolio accordingly.</li>
        </ol>
        
        <h2>When to Take Action</h2>
        
        <p>While it's generally advisable to stay the course during volatile periods, there are times when action may be appropriate:</p>
        
        <ul>
          <li>Rebalancing your portfolio if asset allocations have drifted significantly</li>
          <li>Tax-loss harvesting to offset capital gains</li>
          <li>Reassessing if your financial situation or goals have changed</li>
        </ul>
        
        <p>Remember, market volatility is normal and often presents opportunities for disciplined investors. By understanding its causes and implementing sound strategies, you can navigate turbulent markets with greater confidence.</p>
      `,
      fr: `
        <p>La volatilité du marché est un terme utilisé pour décrire la fréquence et l'ampleur des mouvements de prix sur les marchés financiers. Pour les nouveaux investisseurs, ces fluctuations peuvent sembler aléatoires et effrayantes, mais comprendre les causes sous-jacentes peut vous aider à naviguer dans des périodes incertaines avec confiance.</p>
        
        <h2>Qu'est-ce qui cause la volatilité du marché?</h2>
        
        <p>Plusieurs facteurs contribuent à la volatilité du marché:</p>
        
        <ul>
          <li><strong>Publications de données économiques:</strong> Les informations sur l'inflation, l'emploi, la croissance du PIB et d'autres indicateurs économiques peuvent déclencher des mouvements de marché.</li>
          <li><strong>Politiques des banques centrales:</strong> Les changements de taux d'intérêt ou de politique monétaire peuvent avoir un impact significatPolitiques des banques centrales:</strong> Les changements de taux d'intérêt ou de politique monétaire peuvent avoir un impact significatif sur le sentiment du marché.</li>
          <li><strong>Événements géopolitiques:</strong> Les guerres, les différends commerciaux, les élections et autres développements politiques créent de l'incertitude.</li>
          <li><strong>Résultats des entreprises:</strong> Les entreprises qui publient des résultats différents des attentes peuvent provoquer des fluctuations de prix.</li>
          <li><strong>Sentiment du marché:</strong> La peur, l'avidité et d'autres émotions peuvent entraîner un comportement irrationnel du marché.</li>
        </ul>
        
        <h2>Construire un portefeuille résilient</h2>
        
        <p>Voici des stratégies pour vous aider à gérer la volatilité:</p>
        
        <ol>
          <li><strong>Diversification:</strong> Répartissez les investissements entre différentes classes d'actifs, secteurs et régions géographiques.</li>
          <li><strong>Perspective à long terme:</strong> Concentrez-vous sur vos objectifs d'investissement plutôt que sur les mouvements à court terme du marché.</li>
          <li><strong>Moyenne d'achat:</strong> Investissez régulièrement indépendamment des conditions du marché pour réduire l'impact de la volatilité.</li>
          <li><strong>Fonds d'urgence:</strong> Maintenez des actifs liquides pour éviter de vendre des investissements pendant les baisses du marché.</li>
          <li><strong>Évaluation des risques:</strong> Comprenez votre tolérance au risque et ajustez votre portefeuille en conséquence.</li>
        </ol>
        
        <h2>Quand agir</h2>
        
        <p>Bien qu'il soit généralement conseillé de maintenir le cap pendant les périodes volatiles, il y a des moments où une action peut être appropriée:</p>
        
        <ul>
          <li>Rééquilibrer votre portefeuille si les allocations d'actifs ont considérablement dérivé</li>
          <li>Récolte des pertes fiscales pour compenser les gains en capital</li>
          <li>Réévaluation si votre situation financière ou vos objectifs ont changé</li>
        </ul>
        
        <p>N'oubliez pas que la volatilité du marché est normale et présente souvent des opportunités pour les investisseurs disciplinés. En comprenant ses causes et en mettant en œuvre des stratégies solides, vous pouvez naviguer sur des marchés turbulents avec plus de confiance.</p>
      `,
    },
  },
  {
    id: 2,
    title: {
      en: "Trading Strategies for 2024",
      fr: "Stratégies de trading pour 2024",
    },
    excerpt: {
      en: "Explore effective trading strategies that can help you navigate the volatile markets in 2024 and beyond.",
      fr: "Explorez des stratégies efficaces de trading qui peuvent vous aider à naviguer sur les marchés volatils en 2024 et au-delà.",
    },
    date: "2024-01-10",
    readTime: 10,
    category: {
      en: "Trading",
      fr: "Trading",
    },
    image: "/placeholder.svg?height=400&width=600",
    content: {
      en: `
        <p>The cryptocurrency market continues to evolve rapidly, presenting both challenges and opportunities for traders. As we move through 2024, several strategies have emerged as particularly effective for navigating this dynamic landscape.</p>
        
        <h2>1. Dollar-Cost Averaging (DCA)</h2>
        
        <p>This time-tested strategy involves investing a fixed amount at regular intervals, regardless of price fluctuations. Benefits include:</p>
        
        <ul>
          <li>Reduced impact of volatility</li>
          <li>Less emotional decision-making</li>
          <li>No need to time the market</li>
        </ul>
        
        <p>DCA is particularly effective for long-term investors who believe in the fundamental value of certain cryptocurrencies but want to mitigate short-term volatility risks.</p>
        
        <h2>2. Technical Analysis with Risk Management</h2>
        
        <p>For active traders, technical analysis remains a crucial tool, but must be paired with strict risk management:</p>
        
        <ul>
          <li>Set stop-loss orders at 2-5% below entry points</li>
          <li>Never risk more than 1-2% of your portfolio on a single trade</li>
          <li>Use multiple timeframe analysis to confirm trends</li>
          <li>Focus on high-volume trading pairs for better liquidity</li>
        </ul>
        
        <h2>3. Liquidity Mining and Yield Farming</h2>
        
        <p>DeFi protocols continue to offer opportunities for generating passive income:</p>
        
        <ul>
          <li>Provide liquidity to decentralized exchanges</li>
          <li>Stake tokens in yield-generating protocols</li>
          <li>Participate in lending platforms</li>
        </ul>
        
        <p>However, be aware of impermanent loss risks and thoroughly research protocols before committing funds.</p>
        
        <h2>4. Event-Based Trading</h2>
        
        <p>Cryptocurrency markets often react strongly to specific events:</p>
        
        <ul>
          <li>Protocol upgrades and hard forks</li>
          <li>Regulatory announcements</li>
          <li>Major partnership announcements</li>
          <li>Token burns or supply changes</li>
        </ul>
        
        <p>Staying informed about upcoming events and understanding their potential impact can provide trading advantages.</p>
        
        <h2>5. Diversification Across Crypto Sectors</h2>
        
        <p>The crypto ecosystem has expanded beyond simple currencies to include:</p>
        
        <ul>
          <li>Layer-1 blockchains</li>
          <li>Layer-2 scaling solutions</li>
          <li>DeFi protocols</li>
          <li>NFT platforms</li>
          <li>Web3 infrastructure</li>
          <li>Gaming and metaverse tokens</li>
        </ul>
        
        <p>Diversifying across these sectors can help manage risk while maintaining exposure to the overall growth of the crypto ecosystem.</p>
        
        <h2>Conclusion</h2>
        
        <p>Successful cryptocurrency trading in 2024 requires a combination of disciplined strategy, risk management, and staying informed about market developments. Whether you prefer passive approaches like DCA or more active trading strategies, adapting to the evolving market conditions will be key to long-term success.</p>
      `,
      fr: `
        <p>Le marché des cryptomonnaies continue d'évoluer rapidement, présentant à la fois des défis et des opportunités pour les traders. Alors que nous avançons en 2024, plusieurs stratégies se sont révélées particulièrement efficaces pour naviguer dans ce paysage dynamique.</p>
        
        <h2>1. Investissement périodique (DCA)</h2>
        
        <p>Cette stratégie éprouvée consiste à investir un montant fixe à intervalles réguliers, indépendamment des fluctuations de prix. Les avantages comprennent:</p>
        
        <ul>
          <li>Impact réduit de la volatilité</li>
          <li>Moins de décisions émotionnelles</li>
          <li>Pas besoin de chronométrer le marché</li>
        </ul>
        
        <p>Le DCA est particulièrement efficace pour les investisseurs à long terme qui croient en la valeur fondamentale de certaines cryptomonnaies mais veulent atténuer les risques de volatilité à court terme.</p>
        
        <h2>2. Analyse technique avec gestion des risques</h2>
        
        <p>Pour les traders actifs, l'analyse technique reste un outil crucial, mais doit être associée à une gestion stricte des risques:</p>
        
        <ul>
          <li>Définir des ordres stop-loss à 2-5% en dessous des points d'entrée</li>
          <li>Ne jamais risquer plus de 1-2% de votre portefeuille sur une seule transaction</li>
          <li>Utiliser l'analyse multi-temporelle pour confirmer les tendances</li>
          <li>Se concentrer sur les paires de trading à volume élevé pour une meilleure liquidité</li>
        </ul>
        
        <h2>3. Mining de liquidité et yield farming</h2>
        
        <p>Les protocoles DeFi continuent d'offrir des opportunités de générer des revenus passifs:</p>
        
        <ul>
          <li>Fournir de la liquidité aux échanges décentralisés</li>
          <li>Staker des tokens dans des protocoles générant du rendement</li>
          <li>Participer à des plateformes de prêt</li>
        </ul>
        
        <p>Cependant, soyez conscient des risques de perte impermanente et recherchez soigneusement les protocoles avant d'engager des fonds.</p>
        
        <h2>4. Trading basé sur les événements</h2>
        
        <p>Les marchés des cryptomonnaies réagissent souvent fortement à des événements spécifiques:</p>
        
        <ul>
          <li>Mises à niveau de protocoles et hard forks</li>
          <li>Annonces réglementaires</li>
          <li>Annonces de partenariats majeurs</li>
          <li>Brûlages de tokens ou changements d'approvisionnement</li>
        </ul>
        
        <p>Rester informé des événements à venir et comprendre leur impact potentiel peut procurer des avantages commerciaux.</p>
        
        <h2>5. Diversification à travers les secteurs crypto</h2>
        
        <p>L'écosystème crypto s'est étendu au-delà des simples monnaies pour inclure:</p>
        
        <ul>
          <li>Blockchains de couche 1</li>
          <li>Solutions de mise à l'échelle de couche 2</li>
          <li>Protocoles DeFi</li>
          <li>Plateformes NFT</li>
          <li>Infrastructure Web3</li>
          <li>Tokens de jeux et du métaverse</li>
        </ul>
        
        <p>La diversification à travers ces secteurs peut aider à gérer les risques tout en maintenant une exposition à la croissance globale de l'écosystème crypto.</p>
        
        <h2>Conclusion</h2>
        
        <p>Le trading réussi de cryptomonnaies en 2024 nécessite une combinaison de stratégie disciplinée, de gestion des risques et de se tenir informé des développements du marché. Que vous préfériez des approches passives comme le DCA ou des stratégies de trading plus actives, s'adapter aux conditions évolutives du marché sera la clé du succès à long terme.</p>
      `,
    },
  },
  {
    id: 3,
    title: {
      en: "Financial Modeling Essentials for Finance Students",
      fr: "Éléments essentiels de modélisation financière pour les étudiants en finance",
    },
    excerpt: {
      en: "Learn the fundamental principles and best practices of financial modeling that every finance student should master.",
      fr: "Apprenez les principes fondamentaux et les meilleures pratiques de la modélisation financière que chaque étudiant en finance devrait maîtriser.",
    },
    date: "2024-02-05",
    readTime: 12,
    category: {
      en: "Financial Modeling",
      fr: "Modélisation Financière",
    },
    image: "/placeholder.svg?height=400&width=600",
    content: {
      en: `
        <p>Financial modeling is a crucial skill for finance students and professionals alike. A well-constructed financial model serves as a powerful tool for decision-making, valuation, forecasting, and risk assessment. This article covers the essential principles and best practices that every finance student should master.</p>
        
        <h2>The Foundation: Understanding Financial Statements</h2>
        
        <p>Before diving into modeling, ensure you have a solid understanding of the three primary financial statements and how they interconnect:</p>
        
        <ul>
          <li><strong>Income Statement:</strong> Shows revenues, expenses, and profitability over a period</li>
          <li><strong>Balance Sheet:</strong> Provides a snapshot of assets, liabilities, and equity at a specific point in time</li>
          <li><strong>Cash Flow Statement:</strong> Tracks cash movements across operating, investing, and financing activities</li>
        </ul>
        
        <p>The relationships between these statements form the backbone of any financial model. For example, net income from the income statement flows to the cash flow statement and affects retained earnings on the balance sheet.</p>
        
        <h2>Key Principles of Effective Financial Modeling</h2>
        
        <h3>1. Clarity and Transparency</h3>
        
        <p>A good financial model should be:</p>
        <ul>
          <li>Easy to follow with clear labels and consistent formatting</li>
          <li>Structured with separate sections for inputs, calculations, and outputs</li>
          <li>Documented with assumptions clearly stated</li>
          <li>Built with formulas that can be audited and understood by others</li>
        </ul>
        
        <h3>2. Flexibility and Scalability</h3>
        
        <p>Your model should:</p>
        <ul>
          <li>Use variables and parameters that can be easily changed</li>
          <li>Incorporate sensitivity analysis capabilities</li>
          <li>Be structured to accommodate additional time periods or scenarios</li>
          <li>Maintain functionality when new data is added</li>
        </ul>
        
        <h3>3. Accuracy and Error Prevention</h3>
        
        <p>To ensure reliability:</p>
        <ul>
          <li>Build error checks and balancing mechanisms</li>
          <li>Use consistent formulas across rows</li>
          <li>Implement data validation where appropriate</li>
          <li>Regularly test the model with different inputs</li>
        </ul>
        
        <h2>Essential Components of a Financial Model</h2>
        
        <h3>1. Assumptions and Inputs</h3>
        
        <p>Dedicate a section for all model inputs, including:</p>
        <ul>
          <li>Growth rates and margins</li>
          <li>Tax rates and depreciation schedules</li>
          <li>Working capital requirements</li>
          <li>Capital expenditure projections</li>
          <li>Discount rates and valuation multiples</li>
        </ul>
        
        <h3>2. Historical and Projected Financial Statements</h3>
        
        <p>Include:</p>
        <ul>
          <li>3-5 years of historical data (when available)</li>
          <li>5-10 years of projections (industry-dependent)</li>
          <li>Clear distinction between historical and projected periods</li>
        </ul>
        
        <h3>3. Supporting Schedules</h3>
        
        <p>Develop detailed calculations for:</p>
        <ul>
          <li>Revenue build-up by product/segment</li>
          <li>Operating expenses breakdown</li>
          <li>Depreciation and amortization schedules</li>
          <li>Debt and interest calculations</li>
          <li>Working capital analysis</li>
        </ul>
        
        <h3>4. Valuation and Analysis</h3>
        
        <p>Include methods such as:</p>
        <ul>
          <li>Discounted Cash Flow (DCF) analysis</li>
          <li>Comparable company analysis</li>
          <li>Precedent transaction analysis</li>
          <li>Sensitivity and scenario analysis</li>
          <li>Key performance indicators (KPIs)</li>
        </ul>
        
        <h2>Technical Skills and Tools</h2>
        
        <p>To excel in financial modeling, develop proficiency in:</p>
        
        <ul>
          <li><strong>Excel:</strong> Master functions like VLOOKUP, INDEX/MATCH, data tables, and conditional formatting</li>
          <li><strong>Shortcuts:</strong> Learn keyboard shortcuts to increase efficiency</li>
          <li><strong>Data Visualization:</strong> Create clear charts and dashboards to communicate insights</li>
          <li><strong>VBA/Macros:</strong> Understand basic automation for complex or repetitive tasks</li>
          <li><strong>Python:</strong> Increasingly valuable for data analysis and model automation</li>
        </ul>
        
        <h2>Conclusion</h2>
        
        <p>Financial modeling is both an art and a science. While technical skills are important, equally crucial is the ability to make reasonable assumptions and interpret results in a business context. As you develop your modeling skills, focus not just on the mechanics but also on the story your model tells about the business or investment opportunity it represents.</p>
        
        <p>By mastering these essentials, you'll build a strong foundation for more advanced modeling techniques and be well-prepared for careers in investment banking, equity research, corporate finance, or financial planning and analysis.</p>
      `,
      fr: `
        <p>La modélisation financière est une compétence cruciale pour les étudiants en finance et les professionnels. Un modèle financier bien construit sert d'outil puissant pour la prise de décision, l'évaluation, la prévision et l'évaluation des risques. Cet article couvre les principes essentiels et les meilleures pratiques que chaque étudiant en finance devrait maîtriser.</p>
        
        <h2>La base: Comprendre les états financiers</h2>
        
        <p>Avant de vous plonger dans la modélisation, assurez-vous d'avoir une solide compréhension des trois principaux états financiers et de leur interconnexion:</p>
        
        <ul>
          <li><strong>Compte de résultat:</strong> Montre les revenus, les dépenses et la rentabilité sur une période</li>
          <li><strong>Bilan:</strong> Fournit un aperçu des actifs, des passifs et des capitaux propres à un moment précis</li>
          <li><strong>Tableau des flux de trésorerie:</strong> Suit les mouvements de trésorerie à travers les activités d'exploitation, d'investissement et de financement</li>
        </ul>
        
        <p>Les relations entre ces états forment l'épine dorsale de tout modèle financier. Par exemple, le résultat net du compte de résultat se répercute sur le tableau des flux de trésorerie et affecte les bénéfices non répartis au bilan.</p>
        
        <h2>Principes clés d'une modélisation financière efficace</h2>
        
        <h3>1. Clarté et transparence</h3>
        
        <p>Un bon modèle financier devrait être:</p>
        <ul>
          <li>Facile à suivre avec des étiquettes claires et un formatage cohérent</li>
          <li>Structuré avec des sections séparées pour les entrées, les calculs et les sorties</li>
          <li>Documenté avec des hypothèses clairement énoncées</li>
          <li>Construit avec des formules qui peuvent être auditées et comprises par d'autres</li>
        </ul>
        
        <h3>2. Flexibilité et évolutivité</h3>
        
        <p>Votre modèle devrait:</p>
        <ul>
          <li>Utiliser des variables et des paramètres qui peuvent être facilement modifiés</li>
          <li>Intégrer des capacités d'analyse de sensibilité</li>
          <li>Être structuré pour accueillir des périodes ou des scénarios supplémentaires</li>
          <li>Maintenir la fonctionnalité lorsque de nouvelles données sont ajoutées</li>
        </ul>
        
        <h3>3. Précision et prévention des erreurs</h3>
        
        <p>Pour assurer la fiabilité:</p>
        <ul>
          <li>Construire des vérifications d'erreurs et des mécanismes d'équilibrage</li>
          <li>Utiliser des formules cohérentes sur les lignes</li>
          <li>Mettre en œuvre la validation des données le cas échéant</li>
          <li>Tester régulièrement le modèle avec différentes entrées</li>
        </ul>
        
        <h2>Composants essentiels d'un modèle financier</h2>
        
        <h3>1. Hypothèses et entrées</h3>
        
        <p>Consacrez une section pour toutes les entrées du modèle, y compris:</p>
        <ul>
          <li>Taux de croissance et marges</li>
          <li>Taux d'imposition et calendriers d'amortissement</li>
          <li>Besoins en fonds de roulement</li>
          <li>Projections de dépenses en capital</li>
          <li>Taux d'actualisation et multiples d'évaluation</li>
        </ul>
        
        <h3>2. États financiers historiques et projetés</h3>
        
        <p>Inclure:</p>
        <ul>
          <li>3-5 ans de données historiques (lorsque disponibles)</li>
          <li>5-10 ans de projections (selon l'industrie)</li>
          <li>Distinction claire entre les périodes historiques et projetées</li>
        </ul>
        
        <h3>3. Calendriers de soutien</h3>
        
        <p>Développer des calculs détaillés pour:</p>
        <ul>
          <li>Construction des revenus par produit/segment</li>
          <li>Ventilation des dépenses d'exploitation</li>
          <li>Calendriers d'amortissement</li>
          <li>Calculs de la dette et des intérêts</li>
          <li>Analyse du fonds de roulement</li>
        </ul>
        
        <h3>4. Évaluation et analyse</h3>
        
        <p>Inclure des méthodes telles que:</p>
        <ul>
          <li>Analyse des flux de trésorerie actualisés (DCF)</li>
          <li>Analyse des entreprises comparables</li>
          <li>Analyse des transactions précédentes</li>
          <li>Analyse de sensibilité et de scénario</li>
          <li>Indicateurs clés de performance (KPI)</li>
        </ul>
        
        <h2>Compétences techniques et outils</h2>
        
        <p>Pour exceller dans la modélisation financière, développez des compétences dans:</p>
        
        <ul>
          <li><strong>Excel:</strong> Maîtrisez des fonctions comme RECHERCHEV, INDEX/EQUIV, tableaux de données et mise en forme conditionnelle</li>
          <li><strong>Raccourcis:</strong> Apprenez les raccourcis clavier pour augmenter l'efficacité</li>
          <li><strong>Visualisation des données:</strong> Créez des graphiques et des tableaux de bord clairs pour communiquer des insights</li>
          <li><strong>VBA/Macros:</strong> Comprenez l'automatisation de base pour les tâches complexes ou répétitives</li>
          <li><strong>Python:</strong> De plus en plus précieux pour l'analyse de données et l'automatisation des modèles</li>
        </ul>
        
        <h2>Conclusion</h2>
        
        <p>La modélisation financière est à la fois un art et une science. Si les compétences techniques sont importantes, la capacité à faire des hypothèses raisonnables et à interpréter les résultats dans un contexte commercial est tout aussi cruciale. En développant vos compétences en modélisation, concentrez-vous non seulement sur la mécanique mais aussi sur l'histoire que votre modèle raconte sur l'entreprise ou l'opportunité d'investissement qu'il représente.</p>
        
        <p>En maîtrisant ces éléments essentiels, vous construirez une base solide pour des techniques de modélisation plus avancées et serez bien préparé pour des carrières dans la banque d'investissement, la recherche sur les actions, la finance d'entreprise ou la planification et l'analyse financières.</p>
      `,
    },
  },
]

export default function BlogPage() {
  const { t, language } = useLanguage()
  const [selectedPost, setSelectedPost] = useState<number | null>(null)

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat(language === "en" ? "en-US" : "fr-FR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  return (
    <section id="blog" className="py-20 pt-32 bg-white dark:bg-gray-900 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-primary/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white">{t("blog.title")}</h2>
          <div className="mt-2 h-1 w-20 bg-primary mx-auto"></div>
          <p className="mt-4 text-gray-700 dark:text-gray-300 max-w-2xl mx-auto">{t("blog.description")}</p>
        </motion.div>

        {selectedPost !== null ? (
          <div className="max-w-4xl mx-auto">
            <Button
              variant="ghost"
              className="mb-6 hover:bg-gray-100 dark:hover:bg-gray-800"
              onClick={() => setSelectedPost(null)}
            >
              ← {t("blog.backToAll")}
            </Button>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
                {blogPosts[selectedPost].title[language]}
              </h1>

              <div className="flex flex-wrap items-center text-gray-600 dark:text-gray-400 text-sm mb-6 gap-4">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  {formatDate(blogPosts[selectedPost].date)}
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {blogPosts[selectedPost].readTime} {t("blog.minRead")}
                </div>
                <div className="flex items-center">
                  <Tag className="h-4 w-4 mr-1" />
                  {blogPosts[selectedPost].category[language]}
                </div>
              </div>

              <div className="mb-8 rounded-lg overflow-hidden">
                <img
                  src={blogPosts[selectedPost].image || "/placeholder.svg"}
                  alt={blogPosts[selectedPost].title[language]}
                  className="w-full h-auto object-cover"
                />
              </div>

              <div
                className="prose prose-lg max-w-none dark:prose-invert prose-headings:text-gray-900 dark:prose-headings:text-white prose-p:text-gray-700 dark:prose-p:text-gray-300"
                dangerouslySetInnerHTML={{ __html: blogPosts[selectedPost].content[language] }}
              />
            </motion.div>
          </div>
        ) : (
          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {blogPosts.map((post, index) => (
              <motion.div key={post.id} variants={itemVariants}>
                <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-all duration-300 h-full dark:bg-gray-800">
                  <CardContent className="p-0">
                    <div className="relative">
                      <img
                        src={post.image || "/placeholder.svg"}
                        alt={post.title[language]}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-4 right-4 bg-primary text-white text-xs px-2 py-1 rounded-full">
                        {post.category[language]}
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex items-center text-gray-600 dark:text-gray-400 text-sm mb-3">
                        <Calendar className="h-4 w-4 mr-1" />
                        {formatDate(post.date)}
                        <span className="mx-2">•</span>
                        <Clock className="h-4 w-4 mr-1" />
                        {post.readTime} {t("blog.minRead")}
                      </div>

                      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{post.title[language]}</h3>

                      <p className="text-gray-700 dark:text-gray-300 mb-4">{post.excerpt[language]}</p>

                      <Button
                        onClick={() => setSelectedPost(index)}
                        className="flex items-center text-primary hover:text-primary/90 bg-transparent hover:bg-primary/5 p-0"
                      >
                        {t("blog.readMore")} <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </section>
  )
}

