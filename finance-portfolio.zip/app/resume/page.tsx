"use client"
import { useLanguage } from "@/contexts/language-context"
import { Button } from "@/components/ui/button"
import { Download, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

export default function ResumePage() {
  const { t, language } = useLanguage()
  const router = useRouter()

  // Update the handleDownload function with the new link
  const handleDownload = () => {
    window.open("https://drive.google.com/uc?export=download&id=1UcJuRFPgTNQQG0VUR1HR06VlvOJWFniv", "_blank")
  }

  // Add this script to apply a filter in dark mode
  useEffect(() => {
    // Function to update the iframe filter based on theme
    const updateIframeFilter = () => {
      const isDarkMode = document.documentElement.classList.contains("dark")
      document.documentElement.style.setProperty(
        "--tw-theme-filter",
        isDarkMode ? "invert(0.85) hue-rotate(180deg) contrast(0.9) brightness(0.9)" : "none",
      )
    }

    // Initial call
    updateIframeFilter()

    // Set up a MutationObserver to watch for class changes on the html element
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.attributeName === "class") {
          updateIframeFilter()
        }
      })
    })

    observer.observe(document.documentElement, { attributes: true })

    return () => {
      observer.disconnect()
      document.documentElement.style.removeProperty("--tw-theme-filter")
    }
  }, [])

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <Button variant="ghost" className="hover:bg-gray-100 dark:hover:bg-gray-800" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            {language === "en" ? "Back" : "Retour"}
          </Button>

          <Button onClick={handleDownload} className="bg-primary hover:bg-primary/90">
            <Download className="mr-2 h-4 w-4" />
            {t("nav.downloadCV")}
          </Button>
        </div>

        {/* Update the iframe container to have dark mode styling */}
        <div className="mt-8 w-full max-w-4xl mx-auto bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
          <div className="w-full h-full bg-white dark:bg-gray-800">
            <iframe
              src="https://drive.google.com/file/d/1UcJuRFPgTNQQG0VUR1HR06VlvOJWFniv/preview"
              width="100%"
              height="800px"
              className="border-0"
              allow="autoplay"
              style={{
                backgroundColor: "white",
                filter: "var(--tw-theme-filter, none)",
              }}
            ></iframe>
          </div>
        </div>

        {/* Remove or comment out the motion.div containing the resume content */}
        {/* <motion.div
          className="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-8 max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Davin Doucet</h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">Ottawa, ON, Canada</p>
            <p className="text-gray-600 dark:text-gray-300">514-638-7382 | davindoucet@hotmail.com</p>
            <p className="text-gray-600 dark:text-gray-300">www.linkedin.com/in/davin-doucet</p>
          </div>

          <section className="mb-8">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2 mb-4">
              EDUCATION
            </h2>

            <div className="mb-4">
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-gray-800 dark:text-gray-200">Carleton University</h3>
                <span className="text-gray-600 dark:text-gray-400">Ottawa, ON, Canada</span>
              </div>
              <div className="flex justify-between items-start">
                <p className="text-gray-700 dark:text-gray-300 italic">
                  Bachelor of Commerce (Honors) in Finance with a minor in Forensic Psychology
                </p>
                <span className="text-gray-600 dark:text-gray-400">Expected 2026</span>
              </div>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 mt-2">
                <li>Relevant Coursework: Derivatives, Investment, Financial Accounting, Business Finance</li>
              </ul>
            </div>

            <div>
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-gray-800 dark:text-gray-200">John Abbott College</h3>
                <span className="text-gray-600 dark:text-gray-400">Sainte-Anne-de-Bellevue, QC, Canada</span>
              </div>
              <div className="flex justify-between items-start">
                <p className="text-gray-700 dark:text-gray-300 italic">Engineering Technologies</p>
                <span className="text-gray-600 dark:text-gray-400">Sep 2020 – June 2022</span>
              </div>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 mt-2">
                <li>
                  Relevant Coursework: Mathematical Models 1, Electric Assembly, Control Logic, Design and Simulation
                </li>
              </ul>
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2 mb-4">
              WORK & LEADERSHIP EXPERIENCE
            </h2>

            <div className="mb-6">
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-gray-800 dark:text-gray-200">Duct Masters Inc.</h3>
                <span className="text-gray-600 dark:text-gray-400">Montreal, QC, Canada</span>
              </div>
              <div className="flex justify-between items-start">
                <p className="text-gray-700 dark:text-gray-300 italic">Financial Analyst</p>
                <span className="text-gray-600 dark:text-gray-400">May 2024 – Present</span>
              </div>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 mt-2">
                <li>
                  Analyzed financial statements for budgets exceeding $100,000, supporting forecasting and cash flow
                  management, enhancing financial accuracy by 12%.
                </li>
                <li>
                  Developed reports evaluating business performance, identifying trends, and recommending cost-saving
                  measures, resulting in a 3% reduction in operational costs.
                </li>
                <li>
                  Assisted in preparing financial models to assess the feasibility of new projects and investment
                  opportunities.
                </li>
              </ul>
            </div>

            <div className="mb-6">
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-gray-800 dark:text-gray-200">Independent Trading & Investments</h3>
                <span className="text-gray-600 dark:text-gray-400">Remote</span>
              </div>
              <div className="flex justify-between items-start">
                <p className="text-gray-700 dark:text-gray-300 italic">Trader & Portfolio Manager</p>
                <span className="text-gray-600 dark:text-gray-400">Jan 2024 – Present</span>
              </div>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 mt-2">
                <li>
                  Achieved significant portfolio growth, including a peak ROI of 1740%, by employing high-frequency
                  trading and data-driven strategies.
                </li>
                <li>
                  Execute day and swing trades while applying hedging and risk management strategies, including
                  stop-loss orders and position sizing, reducing drawdowns by 35%.
                </li>
                <li>
                  Stay current with financial markets, monetary policy shifts, and blockchain innovations to guide
                  investment decisions.
                </li>
              </ul>
            </div>

            <div className="mb-6">
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-gray-800 dark:text-gray-200">Commissionaire</h3>
                <span className="text-gray-600 dark:text-gray-400">Ottawa, ON, Canada</span>
              </div>
              <div className="flex justify-between items-start">
                <p className="text-gray-700 dark:text-gray-300 italic">Security Supervisor</p>
                <span className="text-gray-600 dark:text-gray-400">Nov 2023 – May 2024</span>
              </div>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 mt-2">
                <li>
                  Ensured the security and confidentiality of high-risk facilities and information, maintaining
                  compliance with strict protocols.
                </li>
                <li>
                  Control access, operated security-room equipment, and conducted patrols to prevent theft, vandalism,
                  and fire.
                </li>
                <li>
                  Trained junior security staff, enhancing response efficiency by 15%, demonstrating leadership and
                  improving team performance.
                </li>
              </ul>
            </div>

            <div>
              <div className="flex justify-between items-start">
                <h3 className="font-bold text-gray-800 dark:text-gray-200">John Abbott College Lacrosse Team</h3>
                <span className="text-gray-600 dark:text-gray-400">Sainte-Anne-de-Bellevue, QC, Canada</span>
              </div>
              <div className="flex justify-between items-start">
                <p className="text-gray-700 dark:text-gray-300 italic">Team Member</p>
                <span className="text-gray-600 dark:text-gray-400">Sep 2021 – June 2022</span>
              </div>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 mt-2">
                <li>Participated in 12+ collegiate matches, developing strong teamwork, leadership, and discipline.</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2 mb-4">
              SKILLS, ACTIVITIES & INTERESTS
            </h2>

            <ul className="list-disc list-inside text-gray-700 dark:text-gray-300">
              <li>
                <span className="font-semibold">Security Clearance:</span> Secret (Government of Canada)
              </li>
              <li>
                <span className="font-semibold">Languages:</span> Fluent in English and French
              </li>
              <li>
                <span className="font-semibold">Technical Skills:</span> Built financial models, performed forecasting
                and budgeting, and automated workflows using Python, R, and Excel, increasing data efficiency by 20%.
              </li>
              <li>
                <span className="font-semibold">Certifications & Training:</span> Microsoft Finance and Investment
                Program (Coursera, in progress)
              </li>
              <li>
                <span className="font-semibold">Activities:</span> Member, Sprott Finance Students' Association
              </li>
              <li>
                <span className="font-semibold">Interests:</span> Extreme snowboarding, chess, financial coding projects
              </li>
            </ul>
          </section>
        </motion.div> */}
      </div>
    </div>
  )
}

