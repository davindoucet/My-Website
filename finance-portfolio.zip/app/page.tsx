"use client"

import { ArrowDown } from "lucide-react"
import Header from "@/components/header"
import Hero from "@/components/hero"
import About from "@/components/about"
import Resume from "@/components/resume"
import Skills from "@/components/skills"
import Portfolio from "@/components/portfolio"
import Blog from "@/app/blog/page"
import Contact from "@/components/contact"
import Footer from "@/components/footer"
import { motion } from "framer-motion"

export default function Home() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      <Hero />
      <About />
      <Resume />
      <Skills />
      <Portfolio />
      <Blog />
      <Contact />
      <Footer />

      <motion.button
        className="fixed bottom-8 right-8 p-3 bg-primary rounded-full shadow-lg hover:bg-primary/90 transition-all duration-300 z-50"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <ArrowDown className="h-6 w-6 text-white transform rotate-180" />
      </motion.button>
    </div>
  )
}

