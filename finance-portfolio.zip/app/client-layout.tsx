"use client"

import type React from "react"

import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/contexts/theme-context"
import { LanguageProvider } from "@/contexts/language-context"
import LoadingScreen from "@/components/loading-screen"
import ScrollProgressBar from "@/components/scroll-progress-bar"
import { useState, useEffect } from "react"

const inter = Inter({ subsets: ["latin"] })

export default function ClientLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} transition-colors duration-300`}>
        <ThemeProvider>
          <LanguageProvider>
            {isLoading ? (
              <LoadingScreen />
            ) : (
              <>
                <ScrollProgressBar />
                {children}
              </>
            )}
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

