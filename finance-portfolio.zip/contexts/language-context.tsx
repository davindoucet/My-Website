"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

type Language = "en" | "fr"

type LanguageProviderProps = {
  children: React.ReactNode
  defaultLanguage?: Language
}

type LanguageContextType = {
  language: Language
  toggleLanguage: () => void
  t: (key: string) => string
  isTransitioning?: boolean
}

// Complete translations with fully translated "Who I Am" section

const translations = {
  en: {
    // Header
    "nav.home": "Home",
    "nav.about": "About",
    "nav.resume": "Resume",
    "nav.skills": "Skills",
    "nav.portfolio": "Portfolio",
    "nav.blog": "Blog",
    "nav.contact": "Contact",
    "nav.downloadCV": "Download CV",

    // Hero
    "hero.hello": "Hello, I'm",
    "hero.profession": "Finance Student",
    "hero.description":
      "Specializing in financial analysis, trading & investing, and portfolio management. Passionate about leveraging technology to solve complex financial challenges.",
    "hero.viewWork": "View My Work",
    "hero.contactMe": "Contact Me",

    // About
    "about.title": "About Me",
    "about.education": "Education",
    "about.achievements": "Achievements",
    "about.experience": "Experience",
    "about.whoIAm": "Who I Am",
    "about.bio1":
      "As a dedicated finance student, I have honed robust skills in financial analysis, data management, and financial modeling. My proficiency in Python allows me to automate financial processes and efficiently manage large datasets.",
    "about.bio2":
      "Driven by a passion for finance and trading, I continuously strive to enhance my expertise and stay abreast of the latest industry tools and trends. I am eager to apply my knowledge and skills to real-world challenges and make a meaningful impact in the field.",
    "about.name": "Name:",
    "about.email": "Email:",
    "about.location": "Location:",
    "about.languages": "Languages:",

    // Resume
    "resume.title": "My Resume",
    "resume.education": "Education",
    "resume.experience": "Experience",
    "resume.viewResume": "View Resume",

    // Skills
    "skills.title": "My Skills",
    "skills.description":
      "A comprehensive set of technical and soft skills I've developed through education and professional experience.",
    "skills.technical": "Technical Skills",
    "skills.soft": "Soft Skills",
    "skills.certifications": "Certifications",

    // Portfolio
    "portfolio.title": "My Portfolio",
    "portfolio.description":
      "Explore my finance projects and tools. These interactive applications demonstrate my technical skills and financial knowledge.",
    "portfolio.all": "All Projects",
    "portfolio.calculators": "Calculators",
    "portfolio.trackers": "Trackers",
    "portfolio.analyzers": "Analyzers",

    // Blog
    "blog.title": "My Blog",
    "blog.description": "Insights and articles about finance, investments, and market analysis.",
    "blog.readMore": "Read More",
    "blog.viewAll": "View All Articles",
    "blog.backToAll": "Back to all articles",
    "blog.minRead": "min read",

    // Contact
    "contact.title": "Contact Me",
    "contact.description":
      "Feel free to reach out if you have any questions or would like to discuss potential opportunities.",
    "contact.email": "Email",
    "contact.phone": "Phone",
    "contact.location": "Location",
    "contact.sendMessage": "Send Me a Message",
    "contact.yourName": "Your Name",
    "contact.yourEmail": "Your Email",
    "contact.subject": "Subject",
    "contact.message": "Message",
    "contact.send": "Send Message",
    "contact.sending": "Sending...",
    "contact.success": "Thank you for your message! I'll get back to you soon.",
    "contact.callMe": "Give me a call",
    "contact.socialProfiles": "Social Profiles",

    // Footer
    "footer.rights": "All rights reserved.",
    "footer.privacy": "Privacy Policy",
    "footer.terms": "Terms of Service",
    "footer.cookies": "Cookies Policy",
  },
  fr: {
    // Header
    "nav.home": "Accueil",
    "nav.about": "À Propos",
    "nav.resume": "CV",
    "nav.skills": "Compétences",
    "nav.portfolio": "Portfolio",
    "nav.blog": "Blog",
    "nav.contact": "Contact",
    "nav.downloadCV": "Télécharger CV",

    // Hero
    "hero.hello": "Bonjour, je suis",
    "hero.profession": "Étudiant en Finance",
    "hero.description":
      "Spécialisé dans l'analyse financière, le trading et l'investissement, et la gestion de portefeuille. Passionné par l'utilisation de la technologie pour résoudre des défis financiers complexes.",
    "hero.viewWork": "Voir Mon Travail",
    "hero.contactMe": "Me Contacter",

    // About
    "about.title": "À Propos de Moi",
    "about.education": "Éducation",
    "about.achievements": "Réalisations",
    "about.experience": "Expérience",
    "about.whoIAm": "Qui Je Suis",
    "about.bio1":
      "En tant qu'étudiant en finance dévoué, j'ai développé de solides compétences en analyse financière, gestion de données et modélisation financière. Ma maîtrise de Python me permet d'automatiser les processus financiers et de gérer efficacement de grands ensembles de données.",
    "about.bio2":
      "Motivé par une passion pour la finance et le trading, je m'efforce continuellement d'améliorer mon expertise et de rester au courant des derniers outils et tendances du secteur. Je suis désireux d'appliquer mes connaissances et compétences à des défis réels et d'avoir un impact significatif dans le domaine.",
    "about.name": "Nom:",
    "about.email": "Email:",
    "about.location": "Emplacement:",
    "about.languages": "Langues:",

    // Resume
    "resume.title": "Mon CV",
    "resume.education": "Éducation",
    "resume.experience": "Expérience",
    "resume.viewResume": "Voir CV",
    "resume.downloadResume": "Télécharger CV",
    "resume.back": "Retour",
    "resume.personalInfo": "Informations Personnelles",
    "resume.workExperience": "Expérience Professionnelle",
    "resume.educationHistory": "Parcours Éducatif",
    "resume.skills": "Compétences",
    "resume.languages": "Langues",
    "resume.interests": "Intérêts",
    "resume.certifications": "Certifications",
    "resume.coursework": "Cours Pertinents",
    "resume.expected": "Prévu",
    "resume.present": "Présent",
    "resume.relevantCoursework": "Cours Pertinents",
    "resume.technicalSkills": "Compétences Techniques",
    "resume.securityClearance": "Habilitation de Sécurité",
    "resume.activities": "Activités et Intérêts",
    "resume.carletonUniversity": "Université Carleton",
    "resume.bachelorCommerce":
      "Baccalauréat en Commerce (Avec Distinction) en Finance avec une mineure en Psychologie Judiciaire",
    "resume.johnAbbottCollege": "Collège John Abbott",
    "resume.engineeringTech": "Technologies d'Ingénierie",
    "resume.financialAnalyst": "Analyste Financier",
    "resume.trader": "Trader et Gestionnaire de Portefeuille",
    "resume.securitySupervisor": "Superviseur de Sécurité",
    "resume.teamMember": "Membre d'Équipe",
    "resume.lacrosseTeam": "Équipe de Lacrosse du Collège John Abbott",

    // Skills
    "skills.title": "Mes Compétences",
    "skills.description":
      "Un ensemble complet de compétences techniques et personnelles que j'ai développées grâce à l'éducation et à l'expérience professionnelle.",
    "skills.technical": "Compétences Techniques",
    "skills.soft": "Compétences Personnelles",
    "skills.certifications": "Certifications",
    "skills.financialAnalysis": "Analyse Financière",
    "skills.financialAnalysisDesc": "Analyse budgétaire, prévisions et modélisation financière",
    "skills.pythonProgramming": "Programmation Python",
    "skills.pythonProgrammingDesc": "Automatisation, analyse de données et modélisation financière",
    "skills.investmentManagement": "Gestion d'Investissement",
    "skills.investmentManagementDesc": "Optimisation de portefeuille et gestion des risques",
    "skills.trading": "Trading",
    "skills.tradingDesc": "Day trading, stratégies de couverture et analyse de marché",
    "skills.forecasting": "Prévisions",
    "skills.forecastingDesc": "Projections financières, analyse de tendances et modélisation prédictive",
    "skills.dataAnalysis": "Analyse de Données",
    "skills.dataAnalysisDesc": "Traitement, visualisation et interprétation des données",
    "skills.cashFlowManagement": "Gestion de Trésorerie",
    "skills.cashFlowManagementDesc":
      "Optimisation des flux de trésorerie, analyse de liquidité et gestion du fonds de roulement",
    "skills.financialReporting": "Reporting Financier",
    "skills.financialReportingDesc": "Création de rapports financiers complets et présentations",
    "skills.budgetDevelopment": "Développement Budgétaire",
    "skills.budgetDevelopmentDesc": "Création et gestion de budgets dépassant 100 000 $",
    "skills.financialModeling": "Modélisation Financière",
    "skills.financialModelingDesc":
      "Construction de modèles financiers complexes pour l'analyse et la prise de décision",
    "skills.bankingFinance": "Banque et Finance",
    "skills.bankingFinanceDesc": "Compréhension des systèmes bancaires, instruments financiers et marchés",
    "skills.bilingual": "Bilingue (Anglais et Français)",
    "skills.bilingualDesc": "Maîtrise des deux langues",
    "skills.leadership": "Leadership",
    "skills.leadershipDesc": "Gestion d'équipe et direction stratégique",
    "skills.problemSolving": "Résolution de Problèmes",
    "skills.problemSolvingDesc": "Pensée analytique et solutions créatives",
    "skills.teamwork": "Travail d'Équipe",
    "skills.teamworkDesc": "Collaboration et communication efficace",
    "skills.timeManagement": "Gestion du Temps",
    "skills.timeManagementDesc": "Priorisation et gestion des délais",
    "skills.adaptability": "Adaptabilité",
    "skills.adaptabilityDesc": "Flexibilité dans des environnements changeants",
    "skills.secretClearance": "Habilitation Secrète",
    "skills.secretClearanceDesc": "Gouvernement du Canada",
    "skills.microsoftFinance": "Programme Finance et Investissement Microsoft",
    "skills.microsoftFinanceDesc": "Coursera - En Cours",

    // Portfolio
    "portfolio.title": "Mon Portfolio",
    "portfolio.description":
      "Explorez mes projets et outils financiers. Ces applications interactives démontrent mes compétences techniques et mes connaissances financières.",
    "portfolio.all": "Tous les Projets",
    "portfolio.calculators": "Calculateurs",
    "portfolio.trackers": "Trackers",
    "portfolio.analyzers": "Analyseurs",
    "portfolio.loanCalculator": "Calculateur de Prêt",
    "portfolio.loanCalculatorDesc": "Calculez les paiements de prêt, les intérêts et les calendriers d'amortissement.",
    "portfolio.investmentCalculator": "Calculateur de Rendement d'Investissement",
    "portfolio.investmentCalculatorDesc": "Projetez les rendements futurs des investissements avec intérêts composés.",
    "portfolio.budgetTracker": "Suivi Budgétaire",
    "portfolio.budgetTrackerDesc": "Suivez les revenus et les dépenses avec des analyses visuelles.",
    "portfolio.stockAnalyzer": "Analyseur de Portefeuille d'Actions",
    "portfolio.stockAnalyzerDesc": "Analysez la performance des actions et la diversification du portefeuille.",

    // Blog
    "blog.title": "Mon Blog",
    "blog.description": "Perspectives et articles sur la finance, les investissements et l'analyse de marché.",
    "blog.readMore": "Lire Plus",
    "blog.viewAll": "Voir Tous les Articles",
    "blog.backToAll": "Retour à tous les articles",
    "blog.minRead": "min de lecture",

    // Contact
    "contact.title": "Me Contacter",
    "contact.description":
      "N'hésitez pas à me contacter si vous avez des questions ou si vous souhaitez discuter d'opportunités potentielles.",
    "contact.email": "Email",
    "contact.phone": "Téléphone",
    "contact.location": "Emplacement",
    "contact.sendMessage": "Envoyez-moi un Message",
    "contact.yourName": "Votre Nom",
    "contact.yourEmail": "Votre Email",
    "contact.subject": "Sujet",
    "contact.message": "Message",
    "contact.send": "Envoyer Message",
    "contact.sending": "Envoi en cours...",
    "contact.success": "Merci pour votre message! Je vous répondrai bientôt.",
    "contact.callMe": "Appelez-moi",
    "contact.socialProfiles": "Profils Sociaux",

    // Footer
    "footer.rights": "Tous droits réservés.",
    "footer.privacy": "Politique de Confidentialité",
    "footer.terms": "Conditions d'Utilisation",
    "footer.cookies": "Politique de Cookies",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children, defaultLanguage = "en" }: LanguageProviderProps) {
  const [language, setLanguage] = useState<Language>(defaultLanguage)
  const [isTransitioning, setIsTransitioning] = useState(false)

  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language | null
    if (savedLanguage) {
      setLanguage(savedLanguage)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("language", language)
    document.documentElement.lang = language
  }, [language])

  const toggleLanguage = () => {
    setIsTransitioning(true)
    setTimeout(() => {
      setLanguage(language === "en" ? "fr" : "en")
      setIsTransitioning(false)
    }, 300)
  }

  const t = (key: string): string => {
    return translations[language][key] || key
  }

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t, isTransitioning }}>
      <AnimatePresence mode="wait">
        <motion.div
          key={language}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </LanguageContext.Provider>
  )
}

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

